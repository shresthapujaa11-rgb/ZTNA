from django.contrib import admin
from django.urls import path, include

# Uploaded files under /media/ are served by classroom.views.protected_media, which
# checks the requester's permissions, rather than as public static files.
urlpatterns = [
    path("admin/", admin.site.urls),
    path("gateway/", include("gateway.urls")),
    path("", include("classroom.urls")),
]
