# Context Aware Access Gateway for Zero Trust Network Architecture

**Implemented in a classroom management system.** The project is a security-focused Django-based classroom management system for students, teachers, and administrators. The system supports academic management while applying cybersecurity controls to protect user accounts, academic records, uploaded files, administrative functions, and application resources.

The classroom application is the reference implementation for a **context-aware access gateway for zero trust network architecture**: every authenticated request is scored for context risk (network trust, time-of-day, request-rate anomalies, impossible-travel IP changes) and is allowed, challenged with step-up re-authentication, or blocked accordingly, on top of the existing role-based access control. See [Context-Aware Access Gateway (Zero Trust)](#context-aware-access-gateway-zero-trust) below.

## Project Purpose

The project extends a classroom management platform into a security-focused academic application. It provides normal classroom functions such as attendance, task distribution, submissions, grading, and score prediction while emphasizing:

- Authentication and account security
- Role-Based Access Control (RBAC)
- Authorization and restricted resource access
- Academic data integrity and protection
- Secure file-upload handling
- Database and credential protection
- Security logging and monitoring
- Web application security testing
- Security hardening and vulnerability evaluation

All security testing is performed only against the authorized project application and controlled laboratory environment.

## Security Objectives

- Prevent users from accessing functions outside their assigned roles.
- Protect student, teacher, attendance, marks, and submission data.
- Prevent unauthorized modification of academic records.
- Validate and securely handle uploaded files.
- Protect application secrets and database credentials.
- Record important security-related activities for investigation.
- Identify and evaluate security weaknesses through authorized testing.
- Apply security hardening based on testing results.

## Core Features

### User and Access Management

- Role-based accounts for students, teachers, and administrators
- Authentication and session management
- Role-based authorization
- Restricted access to role-specific functions
- Administrative access control

### Academic Management

- Semester, section, subject, and teacher-assignment management
- Attendance recording and attendance history
- Task creation with PDF attachments
- Online student submissions
- Submission review, scores, and feedback
- Mid-term and pre-board marks recording
- Predicted final-exam scores based on attendance, task scores, and previous exam results

### Security Features

- Context-aware access gateway (zero trust policy enforcement point) scoring every request for network, time, and behavioral risk
- Tiered risk response: allow, step-up re-authentication, or block
- Role-Based Access Control (RBAC)
- Server-side authorization checks
- Input and form validation
- Secure file-upload validation
- File type and size restrictions
- Protection of sensitive configuration values
- Environment-variable based secret management
- Database credential protection
- Security event logging
- Security testing and vulnerability assessment
- Security evidence collection through logs, screenshots, and test results

## Technology

- Python 3.10+
- Django 4.2
- MySQL
- PyMySQL
- Bootstrap 5
- NumPy
- pandas
- Django Jazzmin

### Security Testing / Analysis Tools

The exact tools depend on the implemented test environment. Suitable authorized tools include:

- OWASP ZAP or Burp Suite for web application security testing
- Nmap for authorized network/service discovery
- Wireshark for packet and traffic analysis
- Django security checks and application logs
- Python scripts for security testing or automation

## Prerequisites

- Python 3.10 or later
- MySQL Server
- A controlled local or virtual laboratory environment
- Optional security-testing VM such as Kali Linux or Parrot OS

The included development settings currently use MySQL at `127.0.0.1:8889`. Update the configuration if your local MySQL installation uses different values.

## Installation

### 1. Create and activate a virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate
```

On Windows:

```powershell
python -m venv .venv
.venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Create the MySQL database

```sql
CREATE DATABASE test_classroom;
```

### 4. Configure environment variables

Copy `.env.example` to `.env` and set values for your local environment:

```bash
cp .env.example .env
```

`core/settings.py` loads `.env` automatically and reads `DJANGO_SECRET_KEY`, `DJANGO_DEBUG`, `DJANGO_ALLOWED_HOSTS`, and the `DB_*` values from the environment, with safe local-development defaults if a variable is unset. Never commit `.env` (it is already listed in `.gitignore`).

### 5. Apply migrations

```bash
python manage.py migrate
```

### 6. Create an administrator account

```bash
python manage.py createsuperuser
```

Configure the account with the appropriate administrative role.

### 7. Run Django security checks

```bash
python manage.py check --deploy
```

Review the warnings before any production deployment.

### 8. Start the development server

```bash
python manage.py runserver
```

Open:

```text
http://127.0.0.1:8000/
```

The Django admin is available at:

```text
http://127.0.0.1:8000/admin/
```

## Project Layout

```text
core/          Django configuration, settings, and root URL routing
classroom/     Application models, views, routes, templates, and migrations
gateway/       Context-aware access gateway: risk scoring, PEP middleware, step-up auth
templates/     Shared layout components
utils/         Regression model and prediction dataset
media/         Uploaded profile images, task attachments, and submissions
manage.py      Django management entry point
```

## User Roles and Security Boundaries

| Role | Main Capabilities | Security Boundary |
| --- | --- | --- |
| Student | Register, view tasks, upload submissions, view results | Can access only permitted student resources |
| Teacher | Record attendance and marks, create tasks, review submissions, view predictions | Can access only authorized teaching/academic resources |
| Admin | Manage students, teachers, semesters, subjects, and teaching assignments | Administrative functions restricted to authorized administrators |

## Security Model

The application follows a layered security approach:

```text
User
  |
Authentication
  |
Role Identification
  |
Authorization / RBAC
  |
Input Validation
  |
Business Logic
  |
Database / File Storage
  |
Security Logging
```

The main security principles are:

- Confidentiality: prevent unauthorized access to academic and personal information.
- Integrity: prevent unauthorized modification of attendance, marks, submissions, and other records.
- Availability: keep the academic system usable for authorized users.
- Least privilege: users receive only the permissions required for their roles.
- Accountability: important security activities should be recorded in logs.

## File Upload Security

The system supports task attachments and student submissions. File uploads should be treated as an important security boundary.

Recommended controls include:

- Allow only approved file types.
- Restrict maximum upload size.
- Validate file extensions and content where appropriate.
- Generate safe storage names.
- Prevent executable files from being treated as uploaded documents.
- Store uploaded files outside sensitive application code where possible.
- Restrict access to files according to user authorization.
- Record relevant upload events for security monitoring.

## Authentication and Authorization Security

Authentication verifies the identity of a user, while authorization determines what that user is allowed to do.

The application should enforce authorization on the server side for every sensitive operation.

Examples:

```text
Student
  -> View own results
  -> Submit assigned work
  -> Cannot modify marks

Teacher
  -> Manage assigned academic activities
  -> Review submissions
  -> Cannot access unrestricted administration

Admin
  -> Manage system-level academic configuration
```

## Context-Aware Access Gateway (Zero Trust)

The `gateway` app implements a Policy Enforcement Point (PEP) that sits in front of every
authenticated request, in the spirit of zero trust ("never trust, always verify"): the
existing role-based checks decide *what* a user may do, and the gateway continuously
re-evaluates *whether the current request context still looks like that user* before the
role checks are allowed to run.

```text
Request
  |
Authentication (existing)
  |
Context-Aware Access Gateway (PEP)
  |  - network trust (trusted vs. untrusted IP ranges)
  |  - impossible-travel IP change (network changed too fast)
  |  - off-hours state-changing requests
  |  - request-rate / velocity anomalies
  |  - recent failed step-up attempts
  |
  +-- low risk    -> allow, log
  +-- medium risk -> require step-up re-authentication, then allow
  +-- high risk   -> block, log for admin review
  |
Role-Based Access Control (existing)
  |
Business Logic
```

### Components

- `gateway/risk.py` — pure, unit-tested risk-scoring rules, independent of the request/response cycle.
- `gateway/middleware.py` — `ContextAwareAccessMiddleware`, the PEP that calls the risk engine on every authenticated request and enforces the decision.
- `gateway/views.py` — the step-up re-authentication challenge (password re-entry) and the blocked-access page.
- `gateway/models.py`:
  - `TrustedNetwork` — CIDR ranges treated as part of the trusted perimeter (e.g. campus Wi-Fi). Configurable in Django admin.
  - `AccessPolicy` — singleton policy configuration (business hours, risk thresholds, step-up validity window, velocity limits). Configurable in Django admin.
  - `UserAccessProfile` — rolling per-account context (last IP, last seen time) used to detect anomalies between requests.
  - `AccessDecisionLog` — audit trail of every risk decision, for evidence and admin review.

### Additional zero trust controls

- **Protected uploads** — `/media/` is served by an authorization-checked view (`classroom.views.protected_media`) instead of as public static files; deny by default.
- **Login lockout** — `gateway/loginguard.py` counts failed logins per account and per IP (configurable in `AccessPolicy`) and logs lockouts to `AccessDecisionLog`.
- **Device trust** — `gateway/devices.py` trusts a user's first browser and requires step-up for unrecognised ones; only a hash of the device token is stored (`TrustedDevice`).
- **Multi-factor authentication** — optional TOTP (RFC 6238, `gateway/totp.py`) required at login and step-up once enabled from *Security (MFA)*.
- **Admin-area verification** — administrators must have verified within `stepup_valid_minutes` to reach `/admin-portal/`, `/admin/` and the verify/reject/delete actions (`AccessPolicy.require_stepup_for_admin`).
- **Shorter sessions** — `SESSION_COOKIE_AGE` defaults to 8 hours.

### Configuring the gateway

1. In Django admin, add one or more `TrustedNetwork` entries (e.g. the campus/lab subnet in CIDR notation). If no trusted networks are configured, the network-trust check is skipped.
2. In Django admin, review the single `AccessPolicy` row and adjust business hours, risk thresholds, step-up validity window, and request-velocity limits as needed. The gateway can be turned off entirely with `is_enabled`.
3. Apply migrations (the `gateway` app's tables are included in the normal `python manage.py migrate` step).

### Known limitations (documented trade-offs for this FYP scope)

- Step-up re-authentication is a redirect to a password-confirmation page; a state-changing request (POST/PUT/PATCH/DELETE) that triggers step-up loses its form data and must be resubmitted after verification. GET requests resume at the original URL automatically.
- Request-velocity tracking uses Django's default in-process cache, so it resets on server restart and is per-process; a production deployment behind multiple workers should use a shared cache (e.g. Redis).
- The impossible-travel check is a coarse heuristic based on IP-prefix change within a configurable time window, not a real GeoIP lookup.
- The gateway reads the connecting IP from `REMOTE_ADDR` only; it does not trust client-supplied headers like `X-Forwarded-For`, since there is no reverse proxy in this deployment to set/strip that header safely. If you later deploy behind a real reverse proxy, update `gateway/risk.py::get_client_ip` to read the proxy's trusted header instead.

## Database and Secret Security

Sensitive configuration values should not be committed to GitHub.

`core/settings.py` reads the secret key and database credentials from environment variables (via `.env`), falling back to unsafe placeholder values only for local development when a variable is unset. Before any production deployment, set real values for every variable in `.env.example` through the environment and confirm the fallback placeholders are never reachable.

Recommended protections include:

- Strong, unique database credentials per environment
- Restricted database access
- No production credentials in Git
- Regular dependency updates
- Database backups
- Least-privilege database accounts

## Security Logging and Monitoring

Security-relevant activities should be recorded where appropriate, including:

- Login attempts
- Authentication failures
- Administrative actions
- Permission-denied events
- Important record modifications
- File uploads
- Security-test events

Logs can be reviewed to identify unusual activity and support incident investigation.

## Security Testing

Testing will be performed only against the authorized local or virtual laboratory environment.

Potential test areas include:

### Authentication Testing

- Invalid login attempts
- Session handling
- Authentication enforcement

### Authorization Testing

- Student attempting teacher functions
- Student attempting administrative functions
- Teacher attempting unauthorized administrative functions
- Access to another user's restricted resources

### Input Validation Testing

- Unexpected form input
- Invalid identifiers
- Invalid parameters
- Boundary values

### File Upload Testing

- Unsupported file types
- Oversized files
- Unsafe filenames
- Unauthorized access to uploaded files

### Configuration Security Testing

- Secret exposure
- Database credential exposure
- Django deployment security warnings
- Debug configuration

### Zero Trust / Context-Aware Gateway Testing

- Access from a trusted vs. an untrusted network/IP range
- State-changing requests attempted outside configured business hours
- Rapid repeated state-changing requests (velocity/rate anomaly)
- Simulated impossible travel (rapid IP/network change between requests)
- Step-up re-authentication bypass attempts (submitting the original request without completing step-up)
- Behavior when the gateway is disabled (`AccessPolicy.is_enabled = False`) versus enabled

### Web Application Testing

Authorized security tools may be used to identify common web application weaknesses. Findings should be documented with:

- Vulnerability
- Affected component
- Risk/severity
- Evidence
- Expected behavior
- Observed behavior
- Recommended mitigation

## Security Algorithm / Mechanism

The project will implement or evaluate at least one security mechanism as required by the FYP.

A suitable option for this project is **SHA-256 hashing for integrity verification**, where appropriate.

Example concept:

```text
Original File/Data
       |
     SHA-256
       |
Integrity Hash
       |
Compare During Verification
       |
Match = Integrity maintained
Mismatch = Data/File changed
```

Task attachments and online submissions are hashed with SHA-256 when they are saved. The resulting digest is stored with each record (`attachment_sha256`) and can be recalculated during an integrity review to detect a changed file. Apply migration `0009_attachment_integrity_hashes` with `python manage.py migrate` before using this feature.

## Development and Security Notes

- File uploads are currently stored in `media/` and served by Django while `DEBUG=True`.
- `DEBUG=True` should not be used in production; set `DJANGO_DEBUG=False` in `.env` for deployment.
- Do not commit `.env` files or real credentials to GitHub.
- Review Django security warnings using `python manage.py check --deploy`.
- Keep dependencies updated.
- Run the test suite with:

```bash
python manage.py test
```

## Evidence and Testing Records

For the FYP, maintain evidence such as:

- Application screenshots
- Successful and failed authorization tests
- Security-tool outputs
- Application logs
- File-upload test results
- Configuration before/after hardening
- Database/security configuration evidence
- Vulnerability assessment results
- Test-case results
- Gateway access-decision logs (`AccessDecisionLog` in Django admin) showing allow/step-up/block decisions

## Ethical and Legal Use

All security testing must be performed against the student's own application or another system for which explicit authorization has been provided.

Do not use this project to attack real websites, networks, accounts, databases, or services without written permission.

## GitHub Usage

The project repository should contain:

- Source code
- Security configuration
- Scripts
- Test cases
- Security documentation
- Sanitized logs
- Screenshots/evidence where appropriate
- `README.md`
- Regular commits

Never upload:

- Real passwords
- Database credentials
- Django production secret keys
- API keys
- Private certificates
- Sensitive personal information
- Unnecessary raw user data

## Future Security Enhancements

Possible future improvements include:

- Multi-factor authentication
- Stronger password policies
- Email-based account verification
- Centralized security monitoring
- Web Application Firewall
- SIEM integration
- Automated vulnerability scanning
- Improved file-content validation
- Security alerting
- Rate limiting and brute-force protection
- Automated security testing in CI/CD

## License

No license file is currently included. Add an appropriate license before distributing or publicly reusing the project.
