"""Small, reusable security helpers for request authorization and uploads."""

from pathlib import Path
from hashlib import sha256

from django.conf import settings

from .models import MyUser, Submission, Task, TeacherTeaches


PDF_SIGNATURE = b"%PDF-"
IMAGE_SIGNATURES = {
    ".jpg": (b"\xff\xd8\xff",),
    ".jpeg": (b"\xff\xd8\xff",),
    ".png": (b"\x89PNG\r\n\x1a\n",),
    ".webp": (b"RIFF",),
}


def can_access_subject(user, subject):
    """Return whether a user may access a subject's academic resources."""
    if not user.is_authenticated:
        return False
    if user.role == "teacher":
        return TeacherTeaches.objects.filter(teacher=user, subject=subject).exists()
    if user.role == "student":
        return user.semester_id == subject.semester_id
    return False


DEFAULT_PROFILE_IMAGE = "profile/default-user.jpg"


def can_access_media(user, name):
    """Return whether a user may download the uploaded file stored at `name`.

    Deny by default: a path that doesn't map to a known record is never served.
    """
    if not user.is_authenticated:
        return False
    if user.role == "admin" or user.is_superuser:
        return True
    if name == DEFAULT_PROFILE_IMAGE:
        return True
    if name.startswith("tasks/"):
        task = Task.objects.filter(attachment=name).select_related("subject").first()
        return task is not None and can_access_subject(user, task.subject)
    if name.startswith("submissions/"):
        submission = (
            Submission.objects.filter(attachment=name).select_related("task__subject").first()
        )
        if submission is None:
            return False
        if submission.student_id == user.pk:
            return True
        return (
            user.role == "teacher"
            and TeacherTeaches.objects.filter(
                teacher=user, subject=submission.task.subject
            ).exists()
        )
    if name.startswith("profile/"):
        return MyUser.objects.filter(pk=user.pk, profile_image=name).exists()
    return False


def validate_upload(upload, allowed_extensions, signatures, max_size=None):
    """Validate filename, size, and file signature without trusting the MIME header."""
    if not upload:
        return "Please choose a file."

    extension = Path(upload.name).suffix.lower()
    if extension not in allowed_extensions:
        return "This file type is not allowed."

    max_size = max_size or settings.MAX_UPLOAD_SIZE
    if upload.size > max_size:
        return f"Files must be {max_size // (1024 * 1024)} MB or smaller."

    header = upload.read(16)
    upload.seek(0)
    valid_signatures = signatures.get(extension, ())
    if extension == ".webp":
        is_valid = header.startswith(b"RIFF") and header[8:12] == b"WEBP"
    else:
        is_valid = any(header.startswith(signature) for signature in valid_signatures)
    if not is_valid:
        return "The file contents do not match its extension."
    return None


def validate_pdf(upload):
    return validate_upload(upload, {".pdf"}, {".pdf": (PDF_SIGNATURE,)})


def validate_profile_image(upload):
    return validate_upload(
        upload,
        set(IMAGE_SIGNATURES),
        IMAGE_SIGNATURES,
        settings.MAX_PROFILE_IMAGE_SIZE,
    )


def sha256_for_upload(upload):
    """Return a SHA-256 integrity value and restore the upload cursor."""
    digest = sha256()
    for chunk in upload.chunks():
        digest.update(chunk)
    upload.seek(0)
    return digest.hexdigest()
