from datetime import timedelta

from django.core.files.uploadedfile import SimpleUploadedFile
from django.template.loader import get_template
from django.test import SimpleTestCase, TestCase
from django.urls import resolve, reverse
from django.utils import timezone

from .models import ExamResults, MyUser, Semester, Subject, Task, TeacherTeaches
from .security import validate_pdf, validate_profile_image
from .validation import Validation


class ValidationTests(SimpleTestCase):
    def test_missing_values_are_treated_as_empty(self):
        self.assertTrue(Validation.is_empty(None))
        self.assertTrue(Validation.is_empty("   "))
        self.assertFalse(Validation.is_empty("value"))

    def test_pdf_validation_checks_the_file_signature(self):
        valid_pdf = SimpleUploadedFile("work.pdf", b"%PDF-1.7 content")
        fake_pdf = SimpleUploadedFile("work.pdf", b"not a PDF")

        self.assertIsNone(validate_pdf(valid_pdf))
        self.assertEqual(validate_pdf(fake_pdf), "The file contents do not match its extension.")

    def test_profile_image_validation_checks_the_file_signature(self):
        image = SimpleUploadedFile("profile.png", b"\x89PNG\r\n\x1a\nimage data")
        self.assertIsNone(validate_profile_image(image))


class AdminPortalRouteTests(SimpleTestCase):
    def test_admin_portal_routes_resolve(self):
        self.assertEqual(resolve(reverse("admin-portal")).url_name, "admin-portal")
        self.assertEqual(resolve(reverse("approvals")).url_name, "approvals")

    def test_admin_portal_templates_exist(self):
        self.assertIsNotNone(get_template("admin-portal/dashboard.html"))
        self.assertIsNotNone(get_template("admin-portal/approvals.html"))


class SuperuserCreationTests(TestCase):
    def test_superuser_is_an_verified_admin(self):
        admin = MyUser.objects.create_superuser("root@example.com", "pw-Str0ng-pass")
        self.assertEqual(admin.role, "admin")
        self.assertTrue(admin.is_verified)
        self.assertTrue(admin.is_superuser)


class RollNumberTests(TestCase):
    def setUp(self):
        self.sem1 = Semester.objects.create(name="One")
        self.sem2 = Semester.objects.create(name="Two")

    def make(self, name, semester):
        return MyUser.objects.create_user(
            f"{name}@example.com", "pw", full_name=name, semester=semester
        )

    def rolls(self, semester):
        return list(
            MyUser.objects.filter(semester=semester)
            .order_by("full_name")
            .values_list("full_name", "roll_number")
        )

    def test_roll_numbers_follow_name_order(self):
        self.make("Bina", self.sem1)
        self.make("Asha", self.sem1)
        self.assertEqual(self.rolls(self.sem1), [("Asha", "1"), ("Bina", "2")])

    def test_moving_or_deleting_a_student_renumbers_the_old_semester(self):
        asha = self.make("Asha", self.sem1)
        self.make("Bina", self.sem1)
        self.make("Cara", self.sem1)
        asha.semester = self.sem2
        asha.save()
        self.assertEqual(self.rolls(self.sem1), [("Bina", "1"), ("Cara", "2")])
        self.assertEqual(self.rolls(self.sem2), [("Asha", "1")])
        MyUser.objects.get(full_name="Bina").delete()
        self.assertEqual(self.rolls(self.sem1), [("Cara", "1")])


class ViewRegressionTests(TestCase):
    def setUp(self):
        self.admin = MyUser.objects.create_superuser("root@example.com", "pw-Str0ng-pass")
        self.semester = Semester.objects.create(name="One")
        self.subject = Subject.objects.create(name="Maths", semester=self.semester)
        self.teacher = MyUser.objects.create_user(
            "t@example.com", "pw", full_name="Tina", role="teacher", is_verified=True
        )
        TeacherTeaches.objects.create(teacher=self.teacher, subject=self.subject)
        self.student = MyUser.objects.create_user(
            "s@example.com", "pw", full_name="Sam", semester=self.semester, is_verified=True
        )

    def login_admin(self):
        """Log in as admin and mark them freshly verified (the gateway requires it)."""
        self.client.force_login(self.admin)
        session = self.client.session
        session["stepup_verified_at"] = timezone.now().isoformat()
        session.save()

    def test_admin_can_verify_a_pending_student(self):
        pending = MyUser.objects.create_user("p@example.com", "pw", full_name="Pat")
        self.login_admin()
        response = self.client.post(reverse("verify-user", args=[pending.pk]))
        self.assertRedirects(response, reverse("students"), fetch_redirect_response=False)
        pending.refresh_from_db()
        self.assertTrue(pending.is_verified)

    def test_admin_is_not_listed_as_a_student(self):
        self.login_admin()
        response = self.client.get(reverse("students"))
        self.assertNotIn(self.admin, response.context["students"])

    def test_student_register_rejects_a_non_numeric_semester(self):
        response = self.client.post(
            reverse("student-register"),
            {
                "full_name": "New",
                "email": "new@example.com",
                "password": "Str0ng-pass-99",
                "confirm_password": "Str0ng-pass-99",
                "semester_id": "abc",
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertFalse(MyUser.objects.filter(email="new@example.com").exists())

    def test_invalid_attendance_date_does_not_crash(self):
        self.client.force_login(self.teacher)
        response = self.client.get(
            reverse("single-attendance", args=[self.subject.slug, "not-a-date"])
        )
        self.assertRedirects(response, reverse("error"), fetch_redirect_response=False)

    def test_record_marks_rejects_bad_values_without_partial_saves(self):
        second = MyUser.objects.create_user(
            "s2@example.com", "pw", full_name="Zed", semester=self.semester, is_verified=True
        )
        self.client.force_login(self.teacher)
        url = reverse("record-marks", args=[self.subject.slug])
        for bad in ("", "abc", "-1", "101"):
            self.client.post(
                url,
                {
                    "exam_type": "mid-term",
                    "full_marks": "100",
                    f"marks_{self.student.id}": "50",
                    f"marks_{second.id}": bad,
                },
            )
            self.assertEqual(ExamResults.objects.count(), 0, bad)
        self.client.post(
            url,
            {
                "exam_type": "mid-term",
                "full_marks": "100",
                f"marks_{self.student.id}": "50",
                f"marks_{second.id}": "70",
            },
        )
        self.assertEqual(ExamResults.objects.count(), 2)

    def test_task_creation_validates_input(self):
        self.client.force_login(self.teacher)
        url = reverse("task", args=[self.subject.slug])
        pdf = lambda: SimpleUploadedFile("a.pdf", b"%PDF-1.7 body")
        future = (timezone.now().date() + timedelta(days=3)).isoformat()
        for data in (
            {"task_type": "bogus", "description": "A long enough description", "duration": future},
            {"task_type": "assignment", "description": "short", "duration": future},
            {"task_type": "assignment", "description": "A long enough description", "duration": ""},
            {"task_type": "assignment", "description": "A long enough description", "duration": "2000-01-01"},
        ):
            self.client.post(url, {**data, "attachment": pdf()})
        self.assertEqual(Task.objects.count(), 0)
        self.client.post(
            url,
            {
                "task_type": "assignment",
                "description": "Chapter 3 exercises, due soon.",
                "duration": future,
                "attachment": pdf(),
            },
        )
        self.assertEqual(Task.objects.count(), 1)

    def test_editing_a_teacher_with_blank_phone_numbers_does_not_collide(self):
        other = MyUser.objects.create_user(
            "t2@example.com", "pw", full_name="Tara", role="teacher", is_verified=True
        )
        self.login_admin()
        for teacher in (self.teacher, other):
            response = self.client.post(
                reverse("edit-teacher", args=[teacher.pk]),
                {"full_name": teacher.full_name, "email": teacher.email, "phone_number": ""},
            )
            self.assertRedirects(response, reverse("teachers"), fetch_redirect_response=False)
        self.assertEqual(MyUser.objects.filter(phone_number__isnull=True, role="teacher").count(), 2)


class HomepageTests(TestCase):
    def test_landing_page_is_public(self):
        response = self.client.get(reverse("index"))
        self.assertContains(response, "Manage your classroom, securely.")
        self.assertContains(response, reverse("login"))

    def test_home_lists_subjects_with_role_appropriate_links(self):
        semester = Semester.objects.create(name="One")
        subject = Subject.objects.create(name="Maths", semester=semester)
        teacher = MyUser.objects.create_user(
            "t@example.com", "pw", full_name="Tina", role="teacher", is_verified=True
        )
        TeacherTeaches.objects.create(teacher=teacher, subject=subject)
        student = MyUser.objects.create_user(
            "s@example.com", "pw", full_name="Sam", semester=semester, is_verified=True
        )
        attendance_url = reverse("attendance", args=[subject.slug])

        self.client.force_login(teacher)
        page = self.client.get(reverse("home"))
        self.assertContains(page, "Maths")
        self.assertContains(page, attendance_url)

        self.client.force_login(student)
        page = self.client.get(reverse("home"))
        self.assertContains(page, "Maths")
        self.assertNotContains(page, attendance_url)
