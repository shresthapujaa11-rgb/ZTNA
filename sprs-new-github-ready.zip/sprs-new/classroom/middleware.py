import logging


security_logger = logging.getLogger("classroom.security")


class SecurityEventMiddleware:
    """Audit authenticated state-changing requests without recording form contents."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            user_id = request.user.pk if getattr(request, "user", None) and request.user.is_authenticated else None
            security_logger.info(
                "security_event method=%s path=%s status=%s user_id=%s remote_addr=%s",
                request.method,
                request.path,
                response.status_code,
                user_id,
                request.META.get("REMOTE_ADDR", "unknown"),
            )
        return response
