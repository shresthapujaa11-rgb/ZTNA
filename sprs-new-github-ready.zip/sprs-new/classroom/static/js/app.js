(function () {
  "use strict";

  var bar = document.createElement("div");
  bar.id = "nav-progress";
  document.body.appendChild(bar);

  var hideTimeout;

  function startProgress() {
    clearTimeout(hideTimeout);
    bar.classList.add("active");
    bar.style.width = "0%";
    requestAnimationFrame(function () {
      bar.style.width = "70%";
    });
  }

  function finishProgress() {
    bar.style.width = "100%";
    hideTimeout = setTimeout(function () {
      bar.classList.remove("active");
      bar.style.width = "0%";
    }, 250);
  }

  // Resets the bar on a fresh load and on bfcache back/forward restores.
  window.addEventListener("pageshow", finishProgress);

  // Same-tab, same-origin link clicks get an instant loading cue instead of
  // the page just sitting blank until the full reload finishes.
  document.addEventListener("click", function (event) {
    var link = event.target.closest("a[href]");
    if (!link) return;
    if (link.target && link.target !== "_self") return;
    if (link.hasAttribute("data-bs-toggle")) return;

    var href = link.getAttribute("href");
    if (!href || href.startsWith("#") || href.startsWith("javascript:")) return;

    var url;
    try {
      url = new URL(href, window.location.href);
    } catch (err) {
      return;
    }
    if (url.origin !== window.location.origin) return;

    startProgress();
  });

  // Form submissions: show the same loading cue and guard against double
  // submits, without blocking the browser's normal (non-AJAX) submission.
  document.addEventListener("submit", function (event) {
    var form = event.target;
    // A page's own validation may have cancelled the submit; don't lock the button then.
    if (event.defaultPrevented || form.hasAttribute("data-no-progress")) return;

    startProgress();

    var submitter = event.submitter || form.querySelector('[type="submit"]');
    if (submitter && !submitter.disabled) {
      submitter.classList.add("is-loading");
      // Defer disabling so the browser still captures this button's
      // name/value pair as part of the submission that's already underway.
      setTimeout(function () {
        submitter.disabled = true;
      }, 0);
    }
  });
})();
