# Generated manually to add SHA-256 integrity values for uploaded PDFs.

from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("classroom", "0008_remark")]

    operations = [
        migrations.AddField(
            model_name="task",
            name="attachment_sha256",
            field=models.CharField(blank=True, max_length=64),
        ),
        migrations.AddField(
            model_name="submission",
            name="attachment_sha256",
            field=models.CharField(blank=True, max_length=64),
        ),
    ]
