from django.db.models.signals import post_delete, post_save, pre_save
from django.dispatch import receiver
from .models import MyUser


def renumber_students(semester_id):
    """Assign roll numbers 1..n (alphabetical by name) to a semester's students."""
    students = MyUser.objects.filter(role="student", semester_id=semester_id).order_by(
        "full_name", "pk"
    )
    for index, student in enumerate(students, start=1):
        if student.roll_number != str(index):
            # update() avoids re-triggering the post_save signal.
            MyUser.objects.filter(pk=student.pk).update(roll_number=str(index))


@receiver(pre_save, sender=MyUser)
def remember_previous_semester(sender, instance, **kwargs):
    """Track the semester a student is leaving so it can be renumbered too."""
    instance._previous_semester_id = None
    if instance.pk:
        instance._previous_semester_id = (
            MyUser.objects.filter(pk=instance.pk)
            .values_list("semester_id", flat=True)
            .first()
        )


@receiver(post_save, sender=MyUser)
def update_roll_numbers(sender, instance, update_fields=None, **kwargs):
    if instance.role != "student":
        return
    # Saves that only touch roll_number must not trigger another renumbering pass.
    if update_fields is not None and set(update_fields) == {"roll_number"}:
        return
    renumber_students(instance.semester_id)
    previous = getattr(instance, "_previous_semester_id", None)
    if previous is not None and previous != instance.semester_id:
        renumber_students(previous)


@receiver(post_delete, sender=MyUser)
def renumber_after_delete(sender, instance, **kwargs):
    if instance.role == "student":
        renumber_students(instance.semester_id)
