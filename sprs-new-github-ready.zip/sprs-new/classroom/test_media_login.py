import os
import shutil
import tempfile

from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from .models import MyUser, Semester, Subject, Submission, Task, TeacherTeaches


class ProtectedMediaTests(TestCase):
    def setUp(self):
        self.media_root = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.media_root, ignore_errors=True)
        override = override_settings(MEDIA_ROOT=self.media_root)
        override.enable()
        self.addCleanup(override.disable)

        self.sem1 = Semester.objects.create(name="One")
        self.sem2 = Semester.objects.create(name="Two")
        self.subject = Subject.objects.create(name="Maths", semester=self.sem1)
        self.teacher = MyUser.objects.create_user(
            "t@example.com", "pw", full_name="Tina", role="teacher", is_verified=True
        )
        TeacherTeaches.objects.create(teacher=self.teacher, subject=self.subject)
        self.other_teacher = MyUser.objects.create_user(
            "t2@example.com", "pw", full_name="Tara", role="teacher", is_verified=True
        )
        self.student = MyUser.objects.create_user(
            "s@example.com", "pw", full_name="Sam", semester=self.sem1, is_verified=True
        )
        self.classmate = MyUser.objects.create_user(
            "s2@example.com", "pw", full_name="Sia", semester=self.sem1, is_verified=True
        )
        self.outsider = MyUser.objects.create_user(
            "s3@example.com", "pw", full_name="Sol", semester=self.sem2, is_verified=True
        )
        self.task = Task.objects.create(
            subject=self.subject,
            task_type="assignment",
            description="A long enough description",
            attachment=self._write("tasks/work.pdf"),
        )
        self.submission = Submission.objects.create(
            task=self.task, student=self.student, attachment=self._write("submissions/mine.pdf")
        )

    def _write(self, name):
        full = os.path.join(self.media_root, name)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as handle:
            handle.write(b"%PDF-1.7 test")
        return name

    def get(self, user, name):
        if user is not None:
            self.client.force_login(user)
        return self.client.get(f"/media/{name}")

    def test_anonymous_users_are_sent_to_login(self):
        response = self.get(None, "tasks/work.pdf")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login/", response.url)

    def test_task_files_follow_subject_access(self):
        self.assertEqual(self.get(self.student, "tasks/work.pdf").status_code, 200)
        self.assertEqual(self.get(self.teacher, "tasks/work.pdf").status_code, 200)
        self.assertEqual(self.get(self.outsider, "tasks/work.pdf").status_code, 404)
        self.assertEqual(self.get(self.other_teacher, "tasks/work.pdf").status_code, 404)

    def test_submissions_are_private_to_owner_and_subject_teacher(self):
        self.assertEqual(self.get(self.student, "submissions/mine.pdf").status_code, 200)
        self.assertEqual(self.get(self.teacher, "submissions/mine.pdf").status_code, 200)
        self.assertEqual(self.get(self.classmate, "submissions/mine.pdf").status_code, 404)
        self.assertEqual(self.get(self.other_teacher, "submissions/mine.pdf").status_code, 404)

    def test_unknown_files_and_path_traversal_are_refused(self):
        self._write("tasks/orphan.pdf")  # on disk but not attached to any record
        self.assertEqual(self.get(self.teacher, "tasks/orphan.pdf").status_code, 404)
        self.assertEqual(self.get(self.teacher, "tasks/../submissions/mine.pdf").status_code, 404)
        self.assertEqual(self.get(self.teacher, "..%2Fsecret").status_code, 404)


class LoginProtectionTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = MyUser.objects.create_user(
            "s@example.com", "Str0ng-pass-99", full_name="Sam", is_verified=True
        )

    def attempt(self, password, query=""):
        return self.client.post(
            reverse("login") + query, {"email": "s@example.com", "password": password}
        )

    def test_repeated_failures_lock_the_account_out(self):
        for _ in range(5):
            self.attempt("wrong")
        response = self.attempt("Str0ng-pass-99")  # correct password, but locked
        self.assertRedirects(response, reverse("login"), fetch_redirect_response=False)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_success_before_the_limit_resets_the_counter(self):
        for _ in range(4):
            self.attempt("wrong")
        self.attempt("Str0ng-pass-99")
        self.client.logout()
        for _ in range(4):
            self.attempt("wrong")
        self.attempt("Str0ng-pass-99")
        self.assertIn("_auth_user_id", self.client.session)

    def test_login_honours_a_safe_next_and_rejects_external_ones(self):
        response = self.attempt("Str0ng-pass-99", "?next=/task/maths/")
        self.assertEqual(response.url, "/task/maths/")
        self.client.logout()
        response = self.attempt("Str0ng-pass-99", "?next=https://evil.example/")
        self.assertNotIn("evil.example", response.url)
