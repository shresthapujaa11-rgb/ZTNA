# Create your views here.

from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from django.contrib.auth import authenticate, login as login_user, logout as logout_user
from django.contrib.auth.decorators import login_required
from django.contrib.auth.password_validation import validate_password
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.conf import settings
from django.core.exceptions import SuspiciousFileOperation
from django.core.validators import validate_email
from django.db import IntegrityError, transaction
from django.http import FileResponse, Http404, HttpResponseNotAllowed
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST
import logging
import mimetypes
import os
from .validation import Validation as v
from .models import (
    Attendance,
    ExamResults,
    MyUser,
    Remark,
    Semester,
    Subject,
    Submission,
    Task,
    TeacherTeaches,
)
from datetime import datetime
from django.db.models import Avg, Q
from utils.regression import predict_final_exam_score as predict
from django.utils import timezone
from django.utils._os import safe_join
from django.utils.cache import patch_cache_control
from .security import (
    can_access_media,
    can_access_subject,
    sha256_for_upload,
    validate_pdf,
    validate_profile_image,
)
from gateway import devices, loginguard
from gateway.models import AccessPolicy, UserAccessProfile
from gateway.verification import mark_verified, start_mfa_challenge


security_logger = logging.getLogger("classroom.security")


def deny_access(request, reason="authorization_denied"):
    security_logger.warning("%s user_id=%s path=%s", reason, request.user.pk, request.path)
    return redirect("error")


def is_application_admin(user):
    return user.is_authenticated and (user.role == "admin" or user.is_superuser)


def get_manageable_user(pk, role):
    """Limit account-management actions to the role exposed by the portal."""
    return get_object_or_404(MyUser, pk=pk, role=role, is_superuser=False)


def require_subject_access(request, subject):
    return can_access_subject(request.user, subject)


def parse_date(value):
    """Return a date from a YYYY-MM-DD string, or None if it is missing/invalid."""
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None


def is_valid_email(value):
    try:
        validate_email(value)
    except ValidationError:
        return False
    return True


def validate_task_fields(task_type, description, duration, duration_required=True):
    """Return an error message for invalid task form input, else None."""
    if task_type not in dict(Task.TASK_TYPE):
        return "Please select a valid task type."
    if v.is_empty(description) or len(description.strip()) < 10:
        return "Description must be at least 10 characters long."
    if duration or duration_required:
        due_date = parse_date(duration)
        if due_date is None:
            return "Please enter a valid due date."
        if due_date < timezone.now().date():
            return "Due date cannot be in the past."
    return None


def index(request):
    if request.user.is_authenticated:
        return redirect("home")

    return render(request, "index.html")


# home page
@login_required(login_url="login")
def home(request):
    return render(request, "home.html")


def error(request):
    return render(request, "error.html")


def csrf_failure(request, reason=""):
    """Recover from stale browser CSRF tokens without exposing failure details."""
    security_logger.warning("csrf_failure path=%s remote_addr=%s", request.path, request.META.get("REMOTE_ADDR", "unknown"))
    messages.error(request, "Your form session expired. Please try logging in again.")
    response = redirect("login")
    response.delete_cookie(settings.CSRF_COOKIE_NAME)
    return response


# User Login
def login(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        if v.is_empty(email) or v.is_empty(password):
            messages.warning(request, "All fields are required.")
            return redirect("login")

        email = email.strip()
        policy = AccessPolicy.get_solo()
        if loginguard.is_locked(request, email, policy):
            loginguard.log_lockout(request, email, MyUser.objects.filter(email__iexact=email).first())
            security_logger.warning("login_lockout remote_addr=%s", request.META.get("REMOTE_ADDR", "unknown"))
            messages.error(
                request,
                f"Too many failed login attempts. Please try again in {policy.login_lockout_minutes} minutes.",
            )
            return redirect("login")

        user = authenticate(request, email=email, password=password)
        if user:
            if not user.is_verified and not user.is_superuser:
                security_logger.warning("unverified_login user_id=%s", user.pk)
                messages.error(request, "Your account is awaiting administrator approval.")
                return redirect("login")
            loginguard.clear_failures(request, email)

            # Accounts with MFA finish signing in on the authenticator-code page.
            if UserAccessProfile.objects.filter(user=user, totp_enabled=True).exists():
                start_mfa_challenge(request, user)
                return redirect("gateway:mfa-login")

            login_user(request, user)
            mark_verified(request)  # signing in counts as a fresh identity check
            security_logger.info("login_success user_id=%s", user.pk)

            next_url = request.GET.get("next", "")
            if next_url and url_has_allowed_host_and_scheme(
                next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()
            ):
                response = redirect(next_url)
            elif is_application_admin(user):
                response = redirect("admin-portal")
            else:
                response = redirect("index")
            devices.enroll_first_device(request, response, user)
            return response
        else:
            loginguard.record_failure(request, email, policy)
            security_logger.warning("login_failure remote_addr=%s", request.META.get("REMOTE_ADDR", "unknown"))
            messages.error(request, "Invalid username or password")
            return redirect("login")
    return render(request, "auth/login.html")


# User Logout
def logout(request):
    logout_user(request)
    return redirect("login")


# Student Registration
def student_register(request):
    if request.user.is_authenticated:
        return redirect("index")
    semesters = Semester.objects.all()

    if request.method == "POST":
        full_name = request.POST.get("full_name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        semester_id = request.POST.get("semester_id")
        profile_image = request.FILES.get("profile_image")

        if not all([full_name, email, password, semester_id]):
            messages.error(request, "All required fields must be completed.")
            return redirect("student-register")
        if not is_valid_email(email):
            messages.error(request, "Enter a valid email address.")
            return redirect("student-register")
        if password != request.POST.get("confirm_password"):
            messages.error(request, "Passwords do not match.")
            return redirect("student-register")
        try:
            validate_password(password)
        except ValidationError as error:
            messages.error(request, " ".join(error.messages))
            return redirect("student-register")
        upload_error = validate_profile_image(profile_image)
        if upload_error:
            messages.error(request, upload_error)
            return redirect("student-register")

        try:
            MyUser.objects.create_user(
                full_name=full_name,
                email=email,
                password=password,
                semester=Semester.objects.get(id=semester_id),
                profile_image=profile_image,
            )
        except (IntegrityError, Semester.DoesNotExist, ValueError):
            messages.error(request, "Unable to create the account. Check the submitted details.")
            return redirect("student-register")

        messages.success(request, "Account created successfully.")
        return redirect("login")

    context = {
        "semesters": semesters,
    }
    return render(request, "auth/student_register.html", context)


# Teacher Registration
def teacher_register(request):
    if request.user.is_authenticated:
        return redirect("index")
    semesters = Semester.objects.all()

    if request.method == "POST":
        full_name = request.POST.get("full_name")
        email = request.POST.get("email")
        phone_number = request.POST.get("phone_number")
        profile_image = request.FILES.get("profile_image")
        password = request.POST.get("password")

        if not all([full_name, email, phone_number, password]):
            messages.error(request, "All required fields must be completed.")
            return redirect("teacher-register")
        if not is_valid_email(email):
            messages.error(request, "Enter a valid email address.")
            return redirect("teacher-register")
        if password != request.POST.get("confirm_password"):
            messages.error(request, "Passwords do not match.")
            return redirect("teacher-register")
        try:
            validate_password(password)
        except ValidationError as error:
            messages.error(request, " ".join(error.messages))
            return redirect("teacher-register")
        upload_error = validate_profile_image(profile_image)
        if upload_error:
            messages.error(request, upload_error)
            return redirect("teacher-register")

        existing_user = MyUser.objects.filter(email=email).first()
        if existing_user:
            messages.error(request, "Email already exists.")
            return redirect("teacher-register")

        try:
            MyUser.objects.create_user(
                full_name=full_name,
                email=email,
                password=password,
                phone_number=phone_number,
                profile_image=profile_image,
                role="teacher",
            )
        except IntegrityError:
            messages.error(request, "Phone Number is already taken.")
            return redirect("teacher-register")

        messages.success(request, "Account created successfully.")
        return redirect("login")

    context = {
        "semesters": semesters,
    }
    return render(request, "auth/teacher_register.html", context)


# attendance
@login_required(login_url="login")
def attendance(request, pk):
    if request.user.role != "teacher":
        return redirect("error")

    try:
        subject = Subject.objects.get(slug=pk)
        if not require_subject_access(request, subject):
            return deny_access(request)
        students = (
            MyUser.objects.filter(semester=subject.semester, role="student")
            .order_by("roll_number")
            .filter(is_verified=True)
        )

        # Get today's attendance and attendance history
        attendance_taken_for_today = Attendance.objects.filter(
            date=datetime.now().date(), subject=subject
        ).exists()
        # Distinct dates for the given subject
        distinct_dates = (
            Attendance.objects.filter(subject=subject)
            .values("date")
            .distinct()
            .order_by("-date")
        )

        if request.method == "POST":
            for student in students:
                is_present = request.POST.get(str(student.id)) == "on"
                Attendance.objects.update_or_create(
                    date=datetime.now().date(),
                    subject=subject,
                    student=student,
                    defaults={"is_present": is_present},
                )
            messages.success(request, "Attendance saved.")
            return redirect("attendance", pk=pk)

        context = {
            "subject": subject,
            "students": students,
            "attendance_taken_for_today": attendance_taken_for_today,
            "distinct_dates": distinct_dates,
        }
        return render(request, "attendance/attendance.html", context)

    except Subject.DoesNotExist:
        return redirect("error")


# single attendance
@login_required(login_url="login")
def single_attendance(request, pk, date):
    if request.user.role != "teacher":
        return redirect("error")
    try:
        subject = Subject.objects.get(slug=pk)
        if not require_subject_access(request, subject):
            return deny_access(request)
        if parse_date(date) is None:
            return redirect("error")
        attendances = Attendance.objects.filter(date=date, subject=subject).order_by(
            "student__roll_number"
        )

        if request.method == "POST":
            for atd in attendances:
                # Retrieve the student's attendance status from the form
                is_present = request.POST.get(str(atd.student.id)) == "on"
                # Update the attendance record
                atd.is_present = is_present
                atd.save()

            messages.success(request, "Attendance updated successfully.")
            return redirect("single-attendance", pk=pk, date=date)

        context = {
            "subject": subject,
            "attendances": attendances,
            "date": date,
        }
        return render(request, "attendance/single-attendance.html", context)

    except Subject.DoesNotExist:
        return redirect("error")


# task
@login_required(login_url="login")
def task(request, pk):
    if is_application_admin(request.user):
        return redirect("admin-portal")
    try:
        subject = Subject.objects.get(slug=pk)
        if not require_subject_access(request, subject):
            return deny_access(request)
        tasks = Task.objects.filter(subject=subject)
        if request.method == "POST":
            if request.user.role != "teacher":
                return redirect("error")

            task_type = request.POST.get("task_type")
            description = request.POST.get("description")
            attachment = request.FILES.get("attachment")
            duration = request.POST.get("duration")
            field_error = validate_task_fields(task_type, description, duration)
            if field_error:
                messages.error(request, field_error)
                return redirect("task", pk=pk)
            upload_error = validate_pdf(attachment)
            if upload_error:
                messages.error(request, upload_error)
                return redirect("task", pk=pk)
            can_submit_online = (
                True if request.POST.get("can_submit_online") == "true" else False
            )
            Task.objects.create(
                subject=subject,
                task_type=task_type,
                description=description,
                attachment=attachment,
                attachment_sha256=sha256_for_upload(attachment),
                can_submit_online=can_submit_online,
                duration=duration,
            )
            messages.success(request, "Task created successfully.")
            return redirect("task", pk=pk)

        context = {
            "subject": subject,
            "tasks": tasks,
        }
        return render(request, "task/task.html", context)
    except Subject.DoesNotExist:
        return redirect("error")


# single task
@login_required(login_url="login")
def single_task(request, pk, taskId):
    if is_application_admin(request.user):
        return redirect("admin-portal")
    try:
        subject = Subject.objects.get(slug=pk)
        if not require_subject_access(request, subject):
            return deny_access(request)
        # check if this subject is taught by the teacher
        is_teacher = TeacherTeaches.objects.filter(
            teacher=request.user, subject=subject
        ).exists()

        if not is_teacher and request.user.role != "student":
            return redirect("error")

        task = Task.objects.get(id=taskId)
        if task.subject_id != subject.id:
            return deny_access(request, "task_subject_mismatch")
        # Check if the task is past its due date
        current_date = timezone.now().date()
        task_expired = task.duration and task.duration < current_date

        if request.method == "POST":
            if request.user.role != "student":
                return redirect("error")
            if not task.can_submit_online or task_expired:
                return deny_access(request, "invalid_submission_attempt")
            attachment = request.FILES.get("attachment")
            upload_error = validate_pdf(attachment)
            if upload_error:
                messages.error(request, upload_error)
                return redirect("single-task", pk=pk, taskId=taskId)
            try:
                Submission.objects.create(
                    task=task,
                    student=request.user,
                    attachment=attachment,
                    attachment_sha256=sha256_for_upload(attachment),
                )
                messages.success(request, "Assignment submitted.")
            except IntegrityError:
                messages.error(request, "You have already submitted the assignment.")

        submission = Submission.objects.filter(task=task, student=request.user).first()
        all_submissions = Submission.objects.filter(task=task)
        remarks = Remark.objects.filter(submission=submission).first()
        context = {
            "subject": subject,
            "task": task,
            "submission": submission,
            "remarks": remarks,
            "all_submissions": all_submissions,
            "task_expired": task_expired,
        }
        return render(request, "task/single-task.html", context)
    except (Subject.DoesNotExist, Task.DoesNotExist):
        return redirect("error")


# update task
@login_required(login_url="login")
def update_task(request, pk, taskId):
    if is_application_admin(request.user):
        return redirect("admin-portal")
    try:
        subject = Subject.objects.get(slug=pk)
        if not require_subject_access(request, subject):
            return deny_access(request)
        task = Task.objects.get(id=taskId)
        if task.subject_id != subject.id:
            return deny_access(request, "task_subject_mismatch")
        if request.method == "POST":
            if request.user.role != "teacher":
                return redirect("error")
            task_type = request.POST.get("task_type")
            description = request.POST.get("description")
            attachment = request.FILES.get("attachment")
            can_submit_online = (
                True if request.POST.get("can_submit_online") == "true" else False
            )
            duration = request.POST.get("duration")
            # An unchanged (possibly already past) due date must not block other edits.
            field_error = validate_task_fields(
                task_type,
                description,
                None if duration == str(task.duration) else duration,
                duration_required=False,
            )
            if field_error:
                messages.error(request, field_error)
                return redirect("single-task", pk=pk, taskId=taskId)
            if attachment:
                upload_error = validate_pdf(attachment)
                if upload_error:
                    messages.error(request, upload_error)
                    return redirect("single-task", pk=pk, taskId=taskId)
            task.task_type = task_type
            task.description = description
            if attachment:
                task.attachment = attachment
                task.attachment_sha256 = sha256_for_upload(attachment)
            task.can_submit_online = can_submit_online
            if duration:
                task.duration = duration
            task.save()
            messages.success(request, "Task updated successfully.")
        return redirect("task", pk=pk)
    except (Subject.DoesNotExist, Task.DoesNotExist):
        return redirect("error")


# delete task
@login_required(login_url="login")
@require_POST
def delete_task(request, pk, taskId):
    if is_application_admin(request.user):
        return redirect("admin-portal")
    try:
        if request.user.role != "teacher":
            return redirect("error")
        task = Task.objects.get(id=taskId)
        if task.subject.slug != pk or not TeacherTeaches.objects.filter(teacher=request.user, subject=task.subject).exists():
            return deny_access(request)
        if Submission.objects.filter(task=task).exists():
            messages.error(
                request,
                "Task can't be deleted as students have already submitted the assignment.",
            )
            return redirect("task", pk=pk)
        task.delete()
        messages.success(request, "Task deleted successfully.")
        return redirect("task", pk=pk)
    except (Subject.DoesNotExist, Task.DoesNotExist):
        return redirect("error")


# submission
@login_required(login_url="login")
def single_submission(request, pk):
    if is_application_admin(request.user):
        return redirect("admin-portal")
    try:
        user = request.user
        submission = Submission.objects.get(id=pk)

        is_teacher = TeacherTeaches.objects.filter(
            teacher=user, subject=submission.task.subject
        ).exists()

        if not is_teacher or user.role != "teacher":
            return redirect("error")

        existing_remark = Remark.objects.filter(submission=submission).first()

        if request.method == "POST":
            score = request.POST.get("score")
            status = request.POST.get("status")
            feedback = request.POST.get("feedback")

            if score and status in dict(Submission.STATUS_CHOICES) and feedback:
                try:
                    score = int(score)
                    if not 0 <= score <= 10:
                        raise ValueError
                except ValueError:
                    messages.error(request, "Score must be between 0 and 10.")
                    return redirect("submission", pk=pk)
                if existing_remark:
                    existing_remark.score = score
                    existing_remark.feedback = feedback
                    existing_remark.save()
                    submission.status = status
                    submission.save()
                    messages.success(request, "Feedback updated.")
                    return redirect(
                        "single-task",
                        pk=submission.task.subject.slug,
                        taskId=submission.task.id,
                    )
                else:
                    Remark.objects.create(
                        submission=submission,
                        score=score,
                        feedback=feedback,
                    )
                    submission.status = status
                    submission.save()
                    messages.success(request, "Feedback submitted & Score saved.")
                    return redirect(
                        "single-task",
                        pk=submission.task.subject.slug,
                        taskId=submission.task.id,
                    )
            else:
                messages.error(request, "Fill all the fields.")

        context = {"submission": submission, "existing_remark": existing_remark}
        return render(request, "submission/submission.html", context)
    except Submission.DoesNotExist:
        return redirect("error")


# delete submission
@login_required(login_url="login")
@require_POST
def delete_submission(request, pk):
    if is_application_admin(request.user):
        return redirect("admin-portal")
    try:
        submission = Submission.objects.get(id=pk)
        if request.user.role != "student":
            return redirect("error")
        if submission.student != request.user:
            return redirect("error")
        submission.delete()
        messages.success(request, "Submission deleted successfully.")
        return redirect(
            "single-task",
            pk=submission.task.subject.slug,
            taskId=submission.task.id,
        )
    except Submission.DoesNotExist:
        return redirect("error")


# record marks
@login_required(login_url="login")
def record_marks(request, pk):
    if is_application_admin(request.user):
        return redirect("admin-portal")
    try:
        subject = Subject.objects.get(slug=pk)
        if request.user.role != "teacher" or not require_subject_access(request, subject):
            return deny_access(request)
        students = (
            MyUser.objects.filter(semester=subject.semester, role="student")
            .order_by("roll_number")
            .filter(is_verified=True)
        )
        total_exams = (
            ExamResults.objects.values("mid_term", "pre_board")
            .distinct()
            .filter(subject=subject)
        )
        both_recorded = (
            ExamResults.objects.filter(
                student=students.first(), subject=subject
            ).count()
            == 2
        )

        if request.method == "POST":
            exam_type = request.POST.get("exam_type")
            full_marks = request.POST.get("full_marks")

            if exam_type in {"mid-term", "pre-board"} and full_marks:
                try:
                    full_marks = int(full_marks)
                    if full_marks <= 0:
                        raise ValueError
                except ValueError:
                    messages.error(request, "Full marks must be a positive whole number.")
                    return redirect("record-marks", pk=pk)
                mid_term = exam_type == "mid-term"
                pre_board = exam_type == "pre-board"

                entries = []
                for student in students:
                    obtained_marks = request.POST.get(f"marks_{student.id}")
                    if obtained_marks is None:
                        continue
                    try:
                        obtained_marks = int(obtained_marks)
                    except ValueError:
                        messages.error(request, "Marks must be whole numbers.")
                        return redirect("record-marks", pk=pk)
                    if not 0 <= obtained_marks <= full_marks:
                        messages.error(
                            request,
                            f"Marks for {student.full_name} must be between 0 and {full_marks}.",
                        )
                        return redirect("record-marks", pk=pk)
                    entries.append((student, obtained_marks))

                try:
                    # All-or-nothing so a failure doesn't leave half the class recorded.
                    with transaction.atomic():
                        for student, obtained_marks in entries:
                            ExamResults.objects.create(
                                student=student,
                                subject=subject,
                                mid_term=mid_term,
                                pre_board=pre_board,
                                obtained_marks=obtained_marks,
                                full_marks=full_marks,
                            )
                except IntegrityError:
                    messages.error(
                        request,
                        f"Marks already recorded for {exam_type.capitalize() if exam_type == 'mid-term' else 'Pre-Board'}.",
                    )
                    return redirect("record-marks", pk=pk)
                messages.success(
                    request,
                    f"{exam_type.capitalize() if exam_type == 'mid-term' else 'Pre-Board'} marks saved.",
                )
                return redirect("record-marks", pk=pk)
            else:
                messages.error(request, "Please select an exam and enter full marks.")

        context = {
            "subject": subject,
            "students": students,
            "total_exams": total_exams,
            "both_recorded": both_recorded,
        }
        return render(request, "marks/record-marks.html", context)
    except Subject.DoesNotExist:
        return redirect("error")


# single marks
@login_required(login_url="login")
def single_marks(request, pk, exam_type):
    if is_application_admin(request.user):
        return redirect("admin-portal")
    try:
        subject = Subject.objects.get(slug=pk)
        if request.user.role != "teacher" or not require_subject_access(request, subject):
            return deny_access(request)
        if exam_type not in {"mid-term", "pre-board"}:
            return deny_access(request, "invalid_exam_type")
        results = ExamResults.objects.filter(
            subject=subject,
            mid_term=exam_type == "mid-term",
            pre_board=exam_type == "pre-board",
        ).order_by("student__roll_number")

        if request.method == "POST":
            try:
                full_marks = int(request.POST.get("full_marks"))
                if full_marks <= 0:
                    raise ValueError
            except (TypeError, ValueError):
                messages.error(request, "Full marks must be a positive whole number.")
                return redirect("single-marks", pk=pk, exam_type=exam_type)
            form_exam_type = request.POST.get("exam_type")
            if form_exam_type not in {"mid-term", "pre-board"}:
                return deny_access(request, "invalid_exam_type")

            # Flags for the two failure modes
            integrity_error_occurred = False
            marks_error_occurred = False

            try:
                # All-or-nothing so a validation failure doesn't leave partial updates.
                with transaction.atomic():
                    for res in results:
                        marks = request.POST.get(f"marks_{res.student.id}")
                        if not marks:
                            continue
                        try:
                            res.obtained_marks = int(marks)
                        except ValueError:
                            marks_error_occurred = True
                            raise
                        res.full_marks = full_marks
                        res.mid_term = form_exam_type == "mid-term"
                        res.pre_board = form_exam_type == "pre-board"

                        if not 0 <= res.obtained_marks <= res.full_marks:
                            marks_error_occurred = True
                            raise ValueError("marks out of range")

                        res.save()
            except ValueError:
                pass
            except IntegrityError:
                integrity_error_occurred = True

            if marks_error_occurred:
                messages.error(
                    request, "Marks must be whole numbers between 0 and full marks."
                )
                return redirect("single-marks", pk=pk, exam_type=exam_type)
            if integrity_error_occurred:
                messages.error(
                    request, f"Marks already recorded for {form_exam_type.capitalize()}"
                )
                return redirect("single-marks", pk=pk, exam_type=exam_type)
            else:
                messages.success(
                    request, f"{exam_type.capitalize()} marks updated successfully."
                )

            return redirect("single-marks", pk=pk, exam_type=exam_type)

        exam_type_display = "Mid Term" if exam_type == "mid-term" else "Pre Board"
        context = {
            "subject": subject,
            "results": results,
            "exam_type": exam_type_display,
            "full_marks": results.first().full_marks if results.exists() else 100,
        }
        return render(request, "marks/single-marks.html", context)

    except Subject.DoesNotExist:
        messages.error(request, "Subject does not exist.")
        return redirect("error")


# message
@login_required(login_url="login")
def message(request):
    return render(request, "message/message.html")


@login_required(login_url="login")
def prediction(request, pk):
    if is_application_admin(request.user):
        return redirect("admin-portal")

    if request.user.role != "teacher":
        return redirect("error")

    try:
        subject = Subject.objects.get(slug=pk)
        if not require_subject_access(request, subject):
            return deny_access(request)
        students = (
            MyUser.objects.filter(semester=subject.semester, role="student")
            .order_by("roll_number")
            .filter(is_verified=True)
        )
        remarks = Remark.objects.filter(submission__task__subject=subject)
        attendances = Attendance.objects.filter(subject=subject)
        mid_term_results = ExamResults.objects.filter(subject=subject, mid_term=True)
        pre_board_results = ExamResults.objects.filter(subject=subject, pre_board=True)

        student_data = []
        is_data_available = students.exists()

        for student in students:
            # Average task completion score
            student_remarks = remarks.filter(submission__student=student)
            avg_score = (
                student_remarks.aggregate(Avg("score_percentage"))[
                    "score_percentage__avg"
                ]
                or 0
            )
            # Average attendance percentage
            total_attendance = attendances.filter(student=student).count()
            present_attendance = attendances.filter(
                student=student, is_present=True
            ).count()
            avg_attendance = (
                (present_attendance / total_attendance * 100)
                if total_attendance > 0
                else 0
            )

            # Mid-term score
            mid_term = mid_term_results.filter(student=student).first()
            mid_term_score = mid_term.percentage if mid_term else 0

            # Pre-board score
            pre_board = pre_board_results.filter(student=student).first()
            pre_board_score = pre_board.percentage if pre_board else 0

            student_info = {
                "student_id": student.id,
                "student_roll": student.roll_number,
                "student_name": student.full_name,
                "avg_task_score": round(avg_score),
                "avg_attendance": round(avg_attendance),
                "mid_term_score": mid_term_score,
                "pre_board_score": pre_board_score,
                "predicted_score": (
                    round(
                        predict(
                            avg_attendance, avg_score, mid_term_score, pre_board_score
                        ),
                        2,
                    )
                ),
            }

            student_data.append(student_info)

        context = {
            "subject": subject,
            "student_data": student_data,
            "is_data_available": is_data_available,
        }
        return render(request, "prediction/prediction.html", context)
    except Subject.DoesNotExist:
        return redirect("error")


# Uploaded files: served only to users allowed to see them (zero trust for /media/).
@login_required(login_url="login")
def protected_media(request, path):
    parts = path.replace("\\", "/").split("/")
    if any(part in ("", ".", "..") for part in parts):
        raise Http404
    name = "/".join(parts)
    if not can_access_media(request.user, name):
        security_logger.warning("media_access_denied user_id=%s path=%s", request.user.pk, request.path)
        raise Http404
    try:
        full_path = safe_join(settings.MEDIA_ROOT, name)
    except SuspiciousFileOperation:
        raise Http404
    if not os.path.isfile(full_path):
        raise Http404
    content_type = mimetypes.guess_type(full_path)[0] or "application/octet-stream"
    response = FileResponse(open(full_path, "rb"), content_type=content_type)
    patch_cache_control(response, private=True, no_cache=True)
    return response


# ! ==========================================================================================================================
# ! ================================================== ADMIN PANEL ===========================================================
# ! ==========================================================================================================================

# verify students and teachers
# assign semester to students and subjects to teachers
# add subject, semester, and add subject to semester
# admin can update students semester and teachers subjects


@login_required(login_url="login")
def admin_panel(request):
    if not is_application_admin(request.user):
        return redirect("error")
    semesters = Semester.objects.all()
    context = {
        "semesters": semesters,
    }
    return render(request, "admin-portal/dashboard.html", context)


@login_required(login_url="login")
def semesters(request):
    if not is_application_admin(request.user):
        return redirect("error")
    semesters = Semester.objects.all()

    if request.method == "POST" and request.POST.get("add-semester") is not None:
        semester_name = request.POST.get("semester_name")
        if v.is_empty(semester_name):
            messages.error(request, "Semester name is required.")
            return redirect("semesters")
        if not v.is_valid_name(semester_name):
            messages.error(request, "Semester name is invalid.")
            return redirect("semesters")
        try:
            Semester.objects.create(name=semester_name)
            messages.success(request, "Semester added successfully.")
            return redirect("semesters")
        except IntegrityError:
            messages.error(request, "Semester already exists.")
            return redirect("semesters")

    context = {
        "semesters": semesters,
    }
    return render(request, "admin-portal/semesters.html", context)


@login_required(login_url="login")
@require_POST
def delete_semester(request, pk):
    if not is_application_admin(request.user):
        return redirect("error")
    semester = get_object_or_404(Semester, id=pk)
    if MyUser.objects.filter(semester=semester).exists():
        messages.error(request, "Semester has students. Can't delete.")
        return redirect("semesters")
    semester.delete()
    messages.success(request, "Semester deleted successfully.")
    return redirect("semesters")


@login_required(login_url="login")
def semester_subjects(request, name):
    if not is_application_admin(request.user):
        return redirect("error")
    semester = get_object_or_404(Semester, name=name)
    subjects = Subject.objects.filter(semester=semester)

    if request.method == "POST" and request.POST.get("add-subject") is not None:
        subject_name = request.POST.get("subject_name")
        if v.is_empty(subject_name):
            messages.error(request, "Subject name is required.")
            return redirect("semester-subjects", name=name)
        if not v.is_valid_name(subject_name):
            messages.error(request, "Subject name is invalid.")
            return redirect("semester-subjects", name=name)
        try:
            Subject.objects.create(name=subject_name, semester=semester)
            messages.success(request, "Subject added successfully.")
            return redirect("semester-subjects", name=name)
        except IntegrityError:
            messages.error(request, "Subject already exists.")
            return redirect("semester-subjects", name=name)

    context = {
        "semester": semester,
        "subjects": subjects,
    }
    return render(request, "admin-portal/semester-subjects.html", context)


@login_required(login_url="login")
@require_POST
def delete_subject(request, pk):
    if not is_application_admin(request.user):
        return redirect("error")
    subject = get_object_or_404(Subject, id=pk)
    subject.delete()
    messages.success(request, "Subject deleted successfully.")
    return redirect("semester-subjects", name=subject.semester.name)


@login_required(login_url="login")
def students(request):
    if not is_application_admin(request.user):
        return redirect("error")
    
    students = MyUser.objects.filter(role="student").order_by("is_verified")
    q = request.GET.get("q")
    if q:
        students = MyUser.objects.filter(role="student", full_name__icontains=q)
        
    context = {
        "students": students,
    }
    return render(request, "admin-portal/students.html", context)


@login_required(login_url="login")
def teachers(request):
    if not is_application_admin(request.user):
        return redirect("error")
    
    q = request.GET.get("q")
    teachers = MyUser.objects.filter(role="teacher").order_by("is_verified")
    if q:
        teachers = MyUser.objects.filter(role="teacher", full_name__icontains=q)

    context = {
        "teachers": teachers,
    }
    return render(request, "admin-portal/teachers.html", context)


@login_required(login_url="login")
def approvals(request):
    if not is_application_admin(request.user):
        return deny_access(request)

    pending_users = MyUser.objects.filter(
        role__in=["student", "teacher"], is_verified=False
    ).order_by("role", "full_name")
    return render(request, "admin-portal/approvals.html", {"pending_users": pending_users})


@login_required(login_url="login")
def assign_teachers(request):
    if not is_application_admin(request.user):
        return redirect("error")
    teachers = MyUser.objects.filter(role="teacher")
    subjects = Subject.objects.all()
    teacher_teaches = TeacherTeaches.objects.all()

    if request.method == "POST":
        teacher_id = request.POST.get("teacher")
        subject_id = request.POST.get("subject")

        teacher = get_object_or_404(
            MyUser, id=teacher_id, role="teacher", is_verified=True
        )
        subject = get_object_or_404(Subject, id=subject_id)

        if TeacherTeaches.objects.filter(teacher=teacher, subject__semester=subject.semester).exists():
            messages.error(request, "Teacher already assigned to a subject in this semester.")
            return redirect("assign-teachers")
        
        if TeacherTeaches.objects.filter(subject=subject).exists():
            messages.error(request, "Subject already assigned to a teacher.")
            return redirect("assign-teachers")

        try:
            TeacherTeaches.objects.create(teacher=teacher, subject=subject)
        except ValidationError as error:
            messages.error(request, error.messages[0])
            return redirect("assign-teachers")
        messages.success(request, "Subject assigned to teacher successfully.")
        return redirect("assign-teachers")

    context = {
        "teachers": teachers,
        "subjects": subjects,
        "teacher_teaches": teacher_teaches,
    }
    return render(request, "admin-portal/assign-teachers.html", context)

@login_required(login_url="login")
@require_POST
def delete_teacher_teaches(request, pk):
    try:
        if not is_application_admin(request.user):
            return redirect("error")
        teacher_teaches = TeacherTeaches.objects.get(id=pk)
        teacher_teaches.delete()
        messages.success(request, "Subject unassigned from teacher successfully.")
        return redirect("assign-teachers")
    except TeacherTeaches.DoesNotExist:
        return redirect("error")


@login_required(login_url="login")
@require_POST
def verify_user(request, pk):
    if not is_application_admin(request.user):
        return redirect("error")
    user = get_object_or_404(MyUser, pk=pk, role__in=["student", "teacher"], is_superuser=False)
    user.is_verified = True
    user.save()
    messages.success(request, "User verified successfully.")
    if user.role == "student":
        return redirect("students")
    return redirect("teachers")


@login_required(login_url="login")
@require_POST
def reject_user(request, pk):
    if not is_application_admin(request.user):
        return redirect("error")
    user = get_object_or_404(MyUser, pk=pk, role__in=["student", "teacher"], is_superuser=False)
    user.delete()
    messages.success(request, "User rejected.")
    if user.role == "student":
        return redirect("students")
    return redirect("teachers")


@login_required(login_url="login")
@require_POST
def delete_user(request, pk):
    if not is_application_admin(request.user):
        return redirect("error")
    user = get_object_or_404(MyUser, pk=pk, role__in=["student", "teacher"], is_superuser=False)
    user.delete()
    messages.success(request, "User deleted successfully.")
    if user.role == "student":
        return redirect("students")
    return redirect("teachers")


@login_required(login_url="login")
def edit_teacher(request, pk):
    try:
        if not is_application_admin(request.user):
            return redirect("error")
        teacher = get_object_or_404(MyUser, id=pk, role="teacher", is_superuser=False)

        if request.method == "POST":
            full_name = request.POST.get("full_name")
            email = request.POST.get("email")
            phone_number = request.POST.get("phone_number")
            profile_image = request.FILES.get("profile_image")

            if v.is_empty(full_name) or not email or not is_valid_email(email):
                messages.error(request, "A name and a valid email address are required.")
                return redirect("edit-teacher", pk=pk)
            if profile_image:
                upload_error = validate_profile_image(profile_image)
                if upload_error:
                    messages.error(request, upload_error)
                    return redirect("edit-teacher", pk=pk)

            teacher.full_name = full_name
            teacher.email = email
            # phone_number is unique; store blank as NULL so blanks don't collide.
            teacher.phone_number = (phone_number or "").strip() or None
            if profile_image:
                teacher.profile_image = profile_image
            teacher.save()
            messages.success(request, "Teacher updated successfully.")
            return redirect("teachers")
        context = {
            "teacher": teacher,
        }
        return render(request, "admin-portal/edit-teacher.html", context)
    except IntegrityError:
        messages.error(request, "Email address or phone number is already in use.")
        return redirect("teachers")


@login_required(login_url="login")
def edit_student(request, pk):
    try:
        if not is_application_admin(request.user):
            return redirect("error")
        student = get_object_or_404(MyUser, id=pk, role="student", is_superuser=False)
        semesters = Semester.objects.all()

        if request.method == "POST":
            full_name = request.POST.get("full_name")
            email = request.POST.get("email")
            semester_id = request.POST.get("semester_id")
            profile_image = request.FILES.get("profile_image")

            if v.is_empty(full_name) or not email or not is_valid_email(email):
                messages.error(request, "A name and a valid email address are required.")
                return redirect("edit-student", pk=pk)
            try:
                new_semester = Semester.objects.get(id=semester_id)
            except (Semester.DoesNotExist, ValueError, TypeError):
                messages.error(request, "Please select a valid semester.")
                return redirect("edit-student", pk=pk)
            if profile_image:
                upload_error = validate_profile_image(profile_image)
                if upload_error:
                    messages.error(request, upload_error)
                    return redirect("edit-student", pk=pk)

            student.full_name = full_name
            student.email = email
            student.semester = new_semester
            if profile_image:
                student.profile_image = profile_image
            student.save()
            messages.success(request, "Student updated successfully.")
            return redirect("students")
        context = {
            "student": student,
            "semesters": semesters,
        }
        return render(request, "admin-portal/edit-student.html", context)
    except IntegrityError:
        messages.error(request, "Email address is already in use.")
        return redirect("students")
