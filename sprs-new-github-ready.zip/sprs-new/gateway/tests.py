from datetime import time, timedelta

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import RequestFactory, SimpleTestCase, TestCase
from django.utils import timezone

from .models import AccessPolicy, TrustedNetwork, UserAccessProfile
from .risk import check_request_velocity, evaluate_request, get_client_ip, ip_network_key, is_within_business_hours

MyUser = get_user_model()


class PureRiskLogicTests(SimpleTestCase):
    """Rules that don't need the database: network-key grouping and time windows."""

    def test_ipv4_network_key_groups_the_same_subnet(self):
        self.assertEqual(ip_network_key("192.168.1.10"), ip_network_key("192.168.1.200"))
        self.assertNotEqual(ip_network_key("192.168.1.10"), ip_network_key("10.0.0.10"))

    def test_client_ip_ignores_spoofable_forwarded_header(self):
        factory = RequestFactory()
        request = factory.get(
            "/home/",
            REMOTE_ADDR="203.0.113.5",
            HTTP_X_FORWARDED_FOR="10.0.0.1, 1.2.3.4",
        )
        self.assertEqual(get_client_ip(request), "203.0.113.5")

    def test_business_hours_same_day_window(self):
        policy = AccessPolicy(business_hours_start=time(6, 0), business_hours_end=time(22, 0))
        inside = timezone.make_aware(timezone.datetime(2026, 1, 1, 12, 0))
        outside = timezone.make_aware(timezone.datetime(2026, 1, 1, 23, 0))
        self.assertTrue(is_within_business_hours(policy, now=inside))
        self.assertFalse(is_within_business_hours(policy, now=outside))

    def test_business_hours_overnight_window(self):
        policy = AccessPolicy(business_hours_start=time(22, 0), business_hours_end=time(6, 0))
        late_night = timezone.make_aware(timezone.datetime(2026, 1, 1, 23, 30))
        midday = timezone.make_aware(timezone.datetime(2026, 1, 1, 12, 0))
        self.assertTrue(is_within_business_hours(policy, now=late_night))
        self.assertFalse(is_within_business_hours(policy, now=midday))


class EvaluateRequestTests(TestCase):
    def setUp(self):
        cache.clear()
        self.factory = RequestFactory()
        self.user = MyUser.objects.create_user(
            email="student@example.com", password="Str0ngPassw0rd!", role="student"
        )
        self.policy = AccessPolicy.get_solo()

    def _request(self, method="GET", ip="203.0.113.5"):
        request = getattr(self.factory, method.lower())("/home/")
        request.user = self.user
        request.META["REMOTE_ADDR"] = ip
        return request

    def test_trusted_network_request_scores_low(self):
        TrustedNetwork.objects.create(name="Campus", cidr="203.0.113.0/24")
        profile = UserAccessProfile.objects.create(user=self.user)
        result = evaluate_request(self._request(), profile, self.policy)
        self.assertEqual(result.level, "low")
        self.assertEqual(result.decision, "allow")
        self.assertNotIn("untrusted_network", result.reasons)

    def test_untrusted_network_raises_risk(self):
        TrustedNetwork.objects.create(name="Campus", cidr="10.0.0.0/24")
        profile = UserAccessProfile.objects.create(user=self.user)
        result = evaluate_request(self._request(ip="203.0.113.5"), profile, self.policy)
        self.assertIn("untrusted_network", result.reasons)
        self.assertGreater(result.score, 0)

    def test_impossible_travel_between_requests_is_flagged(self):
        profile = UserAccessProfile.objects.create(
            user=self.user,
            last_ip="203.0.113.5",
            last_ip_seen_at=timezone.now() - timedelta(minutes=1),
        )
        result = evaluate_request(self._request(ip="198.51.100.9"), profile, self.policy)
        self.assertIn("impossible_travel", result.reasons)

    def test_request_velocity_spike_triggers_stepup(self):
        self.policy.request_velocity_limit = 2
        self.policy.stepup_risk_threshold = 10
        self.policy.save()
        profile = UserAccessProfile.objects.create(user=self.user)

        results = [
            evaluate_request(self._request(method="POST"), profile, self.policy)
            for _ in range(4)
        ]

        self.assertEqual(results[-1].decision, "stepup_required")
        self.assertIn("request_velocity_spike", results[-1].reasons)


class RequestVelocityWindowTests(SimpleTestCase):
    """The velocity counter must use a fixed window, not one whose expiry slides
    forward on every call -- otherwise a steadily active user's window never
    expires and they stay flagged as a rate anomaly forever."""

    def setUp(self):
        cache.clear()
        self.policy = AccessPolicy(request_velocity_limit=2, request_velocity_window_seconds=60)

    def test_counter_resets_once_the_window_key_is_gone(self):
        self.assertFalse(check_request_velocity(99, self.policy))
        self.assertFalse(check_request_velocity(99, self.policy))
        self.assertTrue(check_request_velocity(99, self.policy))

        # Simulate the window expiring (what a real TTL elapse would do).
        cache.delete("gateway:velocity:99")

        self.assertFalse(check_request_velocity(99, self.policy))


class GatewayMiddlewareIntegrationTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = MyUser.objects.create_user(
            email="teacher@example.com",
            password="Str0ngPassw0rd!",
            role="teacher",
            is_verified=True,
        )
        AccessPolicy.get_solo()

    def test_low_risk_request_passes_through(self):
        self.client.force_login(self.user)
        response = self.client.get("/home/")
        self.assertEqual(response.status_code, 200)

    def test_high_risk_request_is_blocked(self):
        policy = AccessPolicy.get_solo()
        policy.block_risk_threshold = 1
        policy.save()
        TrustedNetwork.objects.create(name="Campus", cidr="10.0.0.0/24")

        self.client.force_login(self.user)
        response = self.client.get("/home/", REMOTE_ADDR="203.0.113.5")
        self.assertRedirects(response, "/gateway/blocked/", target_status_code=403)

    def test_stepup_redirect_and_password_verification(self):
        policy = AccessPolicy.get_solo()
        policy.stepup_risk_threshold = 1
        policy.block_risk_threshold = 1000
        policy.save()
        TrustedNetwork.objects.create(name="Campus", cidr="10.0.0.0/24")

        self.client.force_login(self.user)
        response = self.client.get("/home/", REMOTE_ADDR="203.0.113.5")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/gateway/stepup/", response.url)

        stepup_response = self.client.post(
            response.url, {"password": "Str0ngPassw0rd!", "next": "/home/"}
        )
        self.assertRedirects(stepup_response, "/home/")

    def test_logout_is_never_gated_behind_the_gateway(self):
        policy = AccessPolicy.get_solo()
        policy.block_risk_threshold = 1
        policy.save()
        TrustedNetwork.objects.create(name="Campus", cidr="10.0.0.0/24")

        self.client.force_login(self.user)
        response = self.client.get("/logout/", REMOTE_ADDR="203.0.113.5")
        self.assertRedirects(response, "/login/")
