"""Models backing the context-aware access gateway (zero trust policy engine)."""

import ipaddress
from datetime import time

from django.conf import settings
from django.db import models


class TrustedNetwork(models.Model):
    """A network range treated as part of the trusted perimeter (e.g. campus Wi-Fi)."""

    name = models.CharField(max_length=100)
    cidr = models.CharField(
        max_length=64,
        help_text="IP range in CIDR notation, e.g. 10.0.0.0/24 or 192.168.1.10/32",
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "gateway_trusted_network"
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.cidr})"

    def contains(self, ip_address):
        try:
            network = ipaddress.ip_network(self.cidr, strict=False)
            address = ipaddress.ip_address(ip_address)
        except ValueError:
            return False
        return address in network


class AccessPolicy(models.Model):
    """Singleton policy configuration for the context-aware access gateway."""

    is_enabled = models.BooleanField(
        default=True, help_text="Turn the gateway's risk evaluation on or off."
    )
    business_hours_start = models.TimeField(default=time(6, 0))
    business_hours_end = models.TimeField(default=time(22, 0))
    stepup_risk_threshold = models.PositiveIntegerField(
        default=30, help_text="Score at or above this requires step-up re-authentication."
    )
    block_risk_threshold = models.PositiveIntegerField(
        default=70, help_text="Score at or above this blocks the request outright."
    )
    stepup_valid_minutes = models.PositiveIntegerField(
        default=15, help_text="How long a passed step-up challenge stays valid."
    )
    request_velocity_limit = models.PositiveIntegerField(
        default=20,
        help_text="Max state-changing requests allowed from one account within the velocity window.",
    )
    request_velocity_window_seconds = models.PositiveIntegerField(default=60)
    ip_change_window_minutes = models.PositiveIntegerField(
        default=10,
        help_text=(
            "If the account's network changes within this window, treat it as anomalous "
            "(impossible-travel heuristic)."
        ),
    )
    login_failure_limit = models.PositiveIntegerField(
        default=5,
        help_text="Failed logins for one email within the lockout window before logins are refused.",
    )
    login_lockout_minutes = models.PositiveIntegerField(
        default=15,
        help_text="How long failed logins are counted, and how long a lockout lasts.",
    )
    require_stepup_for_admin = models.BooleanField(
        default=True,
        help_text="Administrators must have re-verified recently to use the admin areas.",
    )
    enforce_device_trust = models.BooleanField(
        default=True,
        help_text="Requests from a device the user has not verified before require step-up.",
    )

    class Meta:
        db_table = "gateway_access_policy"
        verbose_name = "Access policy"
        verbose_name_plural = "Access policy"

    def __str__(self):
        return "Context-aware access policy"

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        return None

    @classmethod
    def get_solo(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj


class UserAccessProfile(models.Model):
    """Rolling context state used to evaluate an account's next request."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="access_profile"
    )
    last_ip = models.GenericIPAddressField(null=True, blank=True)
    last_ip_seen_at = models.DateTimeField(null=True, blank=True)
    last_network_trusted = models.BooleanField(default=False)
    failed_stepup_count = models.PositiveIntegerField(default=0)
    totp_secret = models.CharField(max_length=64, blank=True)
    totp_enabled = models.BooleanField(default=False)
    totp_last_step = models.BigIntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "gateway_user_access_profile"

    def __str__(self):
        return f"Access profile :: {self.user_id}"


class AccessDecisionLog(models.Model):
    """Audit trail of every gateway risk decision, kept for admin review."""

    DECISION_CHOICES = [
        ("allow", "Allowed"),
        ("stepup_required", "Step-up required"),
        ("stepup_passed", "Step-up passed"),
        ("stepup_failed", "Step-up failed"),
        ("blocked", "Blocked"),
    ]
    RISK_CHOICES = [("low", "Low"), ("medium", "Medium"), ("high", "High")]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="access_decisions",
        null=True,
        blank=True,
    )
    path = models.CharField(max_length=255)
    method = models.CharField(max_length=10)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    risk_score = models.PositiveIntegerField(default=0)
    risk_level = models.CharField(choices=RISK_CHOICES, max_length=10)
    decision = models.CharField(choices=DECISION_CHOICES, max_length=20)
    reasons = models.TextField(blank=True, help_text="Comma-separated risk factors that were triggered.")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "gateway_access_decision_log"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.decision} :: {self.risk_level} :: {self.path}"


class TrustedDevice(models.Model):
    """A browser the user has verified. Only a hash of its cookie token is stored."""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="trusted_devices"
    )
    token_hash = models.CharField(max_length=64, unique=True)
    user_agent = models.CharField(max_length=255, blank=True)
    first_ip = models.GenericIPAddressField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_seen_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "gateway_trusted_device"
        ordering = ["-last_seen_at"]

    def __str__(self):
        return f"Device :: {self.user_id} :: {self.user_agent[:40]}"
