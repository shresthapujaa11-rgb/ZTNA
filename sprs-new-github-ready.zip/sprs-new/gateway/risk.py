"""Risk-scoring logic for the context-aware access gateway.

Kept independent of the middleware so the scoring rules are unit-testable
without a full request/response cycle.
"""

import ipaddress
from datetime import timedelta

from django.core.cache import cache
from django.utils import timezone

from .devices import has_devices, is_known_device
from .models import TrustedNetwork

STATE_CHANGING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

UNTRUSTED_NETWORK_WEIGHT = 25
IMPOSSIBLE_TRAVEL_WEIGHT = 40
OFF_HOURS_WEIGHT = 20
VELOCITY_SPIKE_WEIGHT = 25
STEPUP_FAILURE_WEIGHT = 10
STEPUP_FAILURE_CAP = 30
UNRECOGNIZED_DEVICE_WEIGHT = 30

# Paths where an administrator must have verified recently (see require_stepup_for_admin).
SENSITIVE_PATH_PREFIXES = ("/admin-portal/", "/admin/", "/verify/", "/reject/", "/delete/")


class RiskResult:
    def __init__(self, ip_address, network_trusted, score, level, decision, reasons):
        self.ip_address = ip_address
        self.network_trusted = network_trusted
        self.score = score
        self.level = level
        self.decision = decision
        self.reasons = reasons


def get_client_ip(request):
    """Return the connecting IP address.

    Deliberately ignores client-supplied headers such as X-Forwarded-For: this
    deployment has no reverse proxy normalizing that header, so trusting it
    would let a client spoof its network identity and bypass the untrusted-
    network and impossible-travel checks below.
    """
    return request.META.get("REMOTE_ADDR", "0.0.0.0")


def ip_network_key(ip_address):
    """Coarse network identity used for the impossible-travel heuristic."""
    try:
        address = ipaddress.ip_address(ip_address)
    except ValueError:
        return ip_address
    if address.version == 4:
        return ".".join(str(address).split(".")[:3])
    return str(ipaddress.ip_network(f"{address}/48", strict=False))


def is_trusted_network(ip_address, active_networks):
    return any(network.contains(ip_address) for network in active_networks)


def is_within_business_hours(policy, now=None):
    now = now or timezone.localtime()
    start = policy.business_hours_start
    end = policy.business_hours_end
    current = now.time()
    if start <= end:
        return start <= current <= end
    return current >= start or current <= end


def check_request_velocity(user_id, policy):
    """Return True if the account has exceeded the allowed state-changing request rate.

    Uses a fixed window: the counter's expiry is set only when the window is
    first opened, not refreshed on every request. Refreshing it on every call
    (as with a plain get/set) would mean a steadily active user's window never
    expires, so the count would climb forever and the account would stay
    flagged as anomalous indefinitely.
    """
    cache_key = f"gateway:velocity:{user_id}"
    cache.add(cache_key, 0, timeout=policy.request_velocity_window_seconds)
    try:
        count = cache.incr(cache_key)
    except ValueError:
        # Key expired between add() and incr() under concurrent access; reopen the window.
        cache.set(cache_key, 1, timeout=policy.request_velocity_window_seconds)
        count = 1
    return count > policy.request_velocity_limit


def evaluate_request(request, profile, policy):
    reasons = []
    score = 0

    ip_address = get_client_ip(request)
    active_networks = list(TrustedNetwork.objects.filter(is_active=True))
    trusted = is_trusted_network(ip_address, active_networks) if active_networks else True

    if active_networks and not trusted:
        score += UNTRUSTED_NETWORK_WEIGHT
        reasons.append("untrusted_network")

    now = timezone.now()
    if profile.last_ip and profile.last_ip != ip_address and profile.last_ip_seen_at:
        elapsed = now - profile.last_ip_seen_at
        if (
            elapsed <= timedelta(minutes=policy.ip_change_window_minutes)
            and ip_network_key(profile.last_ip) != ip_network_key(ip_address)
        ):
            score += IMPOSSIBLE_TRAVEL_WEIGHT
            reasons.append("impossible_travel")

    is_state_changing = request.method in STATE_CHANGING_METHODS
    if is_state_changing and not is_within_business_hours(policy, now=timezone.localtime(now)):
        score += OFF_HOURS_WEIGHT
        reasons.append("outside_business_hours")

    if is_state_changing and check_request_velocity(request.user.pk, policy):
        score += VELOCITY_SPIKE_WEIGHT
        reasons.append("request_velocity_spike")

    if (
        policy.enforce_device_trust
        and has_devices(request.user)
        and not is_known_device(request, request.user)
    ):
        score += UNRECOGNIZED_DEVICE_WEIGHT
        reasons.append("unrecognized_device")

    if profile.failed_stepup_count:
        score += min(profile.failed_stepup_count * STEPUP_FAILURE_WEIGHT, STEPUP_FAILURE_CAP)
        reasons.append("recent_stepup_failures")

    if score >= policy.block_risk_threshold:
        level, decision = "high", "blocked"
    elif score >= policy.stepup_risk_threshold:
        level, decision = "medium", "stepup_required"
    else:
        level, decision = "low", "allow"

    return RiskResult(
        ip_address=ip_address,
        network_trusted=trusted,
        score=score,
        level=level,
        decision=decision,
        reasons=reasons,
    )
