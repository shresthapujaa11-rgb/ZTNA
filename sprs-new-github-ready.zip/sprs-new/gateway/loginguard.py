"""Brute-force protection for the login form, which the gateway can't see (no user yet)."""

from django.core.cache import cache

from .models import AccessDecisionLog, AccessPolicy
from .risk import get_client_ip

# One IP may be shared by a whole campus, so it gets a higher ceiling than one account.
IP_LIMIT_MULTIPLIER = 4


def _keys(request, email):
    email = (email or "").strip().lower()
    return (
        f"gateway:loginfail:email:{email}",
        f"gateway:loginfail:ip:{get_client_ip(request)}",
    )


def is_locked(request, email, policy=None):
    policy = policy or AccessPolicy.get_solo()
    email_key, ip_key = _keys(request, email)
    limit = policy.login_failure_limit
    return (
        cache.get(email_key, 0) >= limit
        or cache.get(ip_key, 0) >= limit * IP_LIMIT_MULTIPLIER
    )


def record_failure(request, email, policy=None):
    policy = policy or AccessPolicy.get_solo()
    timeout = policy.login_lockout_minutes * 60
    for key in _keys(request, email):
        # Fixed window: the expiry is set once, when the first failure is counted.
        cache.add(key, 0, timeout=timeout)
        try:
            cache.incr(key)
        except ValueError:
            cache.set(key, 1, timeout=timeout)


def clear_failures(request, email):
    cache.delete(_keys(request, email)[0])


def log_lockout(request, email, user=None):
    AccessDecisionLog.objects.create(
        user=user,
        path=request.path,
        method=request.method,
        ip_address=get_client_ip(request),
        risk_score=100,
        risk_level="high",
        decision="blocked",
        reasons="login_lockout",
    )
