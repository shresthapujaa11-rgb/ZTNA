"""Policy Enforcement Point for the context-aware access gateway.

Scores every authenticated request for context risk (untrusted network,
impossible-travel IP changes, off-hours state changes, request-rate spikes)
and enforces a tiered response: allow, require step-up re-authentication, or
block. This is the "gateway" in front of the classroom application's own
role-based authorization, not a replacement for it.
"""

import logging

from urllib.parse import urlencode

from django.shortcuts import redirect
from django.urls import reverse
from django.utils import timezone

from .models import AccessDecisionLog, AccessPolicy, UserAccessProfile
from .risk import SENSITIVE_PATH_PREFIXES, evaluate_request

security_logger = logging.getLogger("gateway.security")

# Uploaded files under /media/ are deliberately NOT exempt: they are served by an
# authenticated view and must pass through the gateway like any other resource.
EXEMPT_PATH_PREFIXES = ("/static/", "/gateway/")
# Logging out must never be gated behind a step-up challenge or block.
EXEMPT_PATHS = ("/logout/",)


class ContextAwareAccessMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if self._should_skip(request):
            return self.get_response(request)

        policy = AccessPolicy.get_solo()
        if not policy.is_enabled:
            return self.get_response(request)

        profile, _ = UserAccessProfile.objects.get_or_create(user=request.user)
        result = evaluate_request(request, profile, policy)

        if result.decision == "stepup_required" and self._stepup_verified(request, policy):
            result.decision = "allow"

        if (
            result.decision == "allow"
            and policy.require_stepup_for_admin
            and self._is_admin(request.user)
            and request.path.startswith(SENSITIVE_PATH_PREFIXES)
            and not self._stepup_verified(request, policy)
        ):
            result.decision = "stepup_required"
            result.level = "medium"
            result.reasons.append("admin_area_requires_recent_verification")

        self._update_profile(profile, result)

        if result.decision == "blocked":
            self._log(request, result, "blocked")
            security_logger.warning(
                "gateway_block user_id=%s path=%s score=%s reasons=%s",
                request.user.pk,
                request.path,
                result.score,
                ",".join(result.reasons),
            )
            return redirect("gateway:blocked")

        if result.decision == "stepup_required":
            self._log(request, result, "stepup_required")
            security_logger.info(
                "gateway_stepup_required user_id=%s path=%s score=%s reasons=%s",
                request.user.pk,
                request.path,
                result.score,
                ",".join(result.reasons),
            )
            stepup_url = reverse("gateway:stepup")
            return redirect(f"{stepup_url}?{urlencode({'next': request.get_full_path()})}")

        self._log(request, result, "allow")
        return self.get_response(request)

    def _should_skip(self, request):
        if not getattr(request, "user", None) or not request.user.is_authenticated:
            return True
        if request.path in EXEMPT_PATHS:
            return True
        return request.path.startswith(EXEMPT_PATH_PREFIXES)

    def _is_admin(self, user):
        return user.role == "admin" or user.is_superuser

    def _stepup_verified(self, request, policy):
        verified_at = request.session.get("stepup_verified_at")
        if not verified_at:
            return False
        try:
            verified_time = timezone.datetime.fromisoformat(verified_at)
        except ValueError:
            return False
        if timezone.is_naive(verified_time):
            verified_time = timezone.make_aware(verified_time)
        return timezone.now() - verified_time <= timezone.timedelta(minutes=policy.stepup_valid_minutes)

    def _update_profile(self, profile, result):
        profile.last_ip = result.ip_address
        profile.last_ip_seen_at = timezone.now()
        profile.last_network_trusted = result.network_trusted
        profile.save(update_fields=["last_ip", "last_ip_seen_at", "last_network_trusted", "updated_at"])

    def _log(self, request, result, decision):
        AccessDecisionLog.objects.create(
            user=request.user,
            path=request.path,
            method=request.method,
            ip_address=result.ip_address,
            risk_score=result.score,
            risk_level=result.level,
            decision=decision,
            reasons=",".join(result.reasons),
        )
