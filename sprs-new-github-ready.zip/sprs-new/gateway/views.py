import logging

from django.contrib import messages
from django.contrib.auth import get_user_model, login as login_user
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.utils.http import url_has_allowed_host_and_scheme

from . import devices, loginguard, totp
from .models import AccessDecisionLog, AccessPolicy, UserAccessProfile
from .verification import clear_mfa_challenge, mark_verified, pending_mfa_user_id

security_logger = logging.getLogger("gateway.security")


def _safe_next(request, fallback="/"):
    next_url = request.GET.get("next") or request.POST.get("next") or fallback
    if not url_has_allowed_host_and_scheme(
        next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()
    ):
        return fallback
    return next_url


def _log_stepup(request, decision, reasons):
    AccessDecisionLog.objects.create(
        user=request.user,
        path=request.path,
        method="POST",
        ip_address=request.META.get("REMOTE_ADDR"),
        risk_score=0,
        risk_level="medium",
        decision=decision,
        reasons=reasons,
    )


@login_required(login_url="login")
def stepup(request):
    """Re-authentication challenge: password, plus an authenticator code when MFA is on."""
    policy = AccessPolicy.get_solo()
    next_url = _safe_next(request)
    profile, _ = UserAccessProfile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        password_ok = request.user.check_password(request.POST.get("password", ""))
        matched_step = None
        code_ok = True
        if profile.totp_enabled:
            matched_step = totp.verify_code(
                profile.totp_secret, request.POST.get("code"), profile.totp_last_step
            )
            code_ok = matched_step is not None

        if password_ok and code_ok:
            mark_verified(request)
            profile.failed_stepup_count = 0
            update_fields = ["failed_stepup_count", "updated_at"]
            if matched_step is not None:
                profile.totp_last_step = matched_step
                update_fields.append("totp_last_step")
            profile.save(update_fields=update_fields)
            _log_stepup(request, "stepup_passed", "stepup_verified")
            security_logger.info("stepup_passed user_id=%s", request.user.pk)
            messages.success(request, "Identity verified.")
            response = redirect(next_url)
            # A verified user's current browser becomes a trusted device.
            devices.ensure_device(request, response, request.user)
            return response

        profile.failed_stepup_count += 1
        profile.save(update_fields=["failed_stepup_count", "updated_at"])
        _log_stepup(
            request,
            "stepup_failed",
            "incorrect_password" if not password_ok else "incorrect_authenticator_code",
        )
        security_logger.warning("stepup_failed user_id=%s", request.user.pk)
        messages.error(request, "Incorrect password or code.")

    return render(
        request,
        "gateway/stepup.html",
        {
            "next": next_url,
            "stepup_valid_minutes": policy.stepup_valid_minutes,
            "mfa_required": profile.totp_enabled,
        },
    )


def mfa_login(request):
    """Second login step for accounts with MFA: the password was already accepted."""
    User = get_user_model()
    user_id = pending_mfa_user_id(request)
    user = User.objects.filter(pk=user_id, is_active=True).first() if user_id else None
    if user is None:
        clear_mfa_challenge(request)
        messages.error(request, "Your sign-in expired. Please log in again.")
        return redirect("login")

    profile, _ = UserAccessProfile.objects.get_or_create(user=user)
    policy = AccessPolicy.get_solo()

    if request.method == "POST":
        if loginguard.is_locked(request, user.email, policy):
            loginguard.log_lockout(request, user.email, user)
            clear_mfa_challenge(request)
            messages.error(request, "Too many failed attempts. Please try again later.")
            return redirect("login")

        step = totp.verify_code(
            profile.totp_secret, request.POST.get("code"), profile.totp_last_step
        )
        if step is None:
            loginguard.record_failure(request, user.email, policy)
            security_logger.warning("mfa_login_failure user_id=%s", user.pk)
            messages.error(request, "Incorrect authenticator code.")
        else:
            profile.totp_last_step = step
            profile.save(update_fields=["totp_last_step", "updated_at"])
            loginguard.clear_failures(request, user.email)
            clear_mfa_challenge(request)
            login_user(request, user, backend="django.contrib.auth.backends.ModelBackend")
            mark_verified(request)
            security_logger.info("login_success user_id=%s mfa=1", user.pk)
            is_admin = user.role == "admin" or user.is_superuser
            response = redirect("admin-portal" if is_admin else "home")
            devices.enroll_first_device(request, response, user)
            return response

    return render(request, "gateway/mfa_login.html")


@login_required(login_url="login")
def mfa_setup(request):
    """Turn authenticator-app MFA on or off for the signed-in user."""
    profile, _ = UserAccessProfile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        action = request.POST.get("action")
        if action == "enable" and not profile.totp_enabled and profile.totp_secret:
            step = totp.verify_code(profile.totp_secret, request.POST.get("code"))
            if step is None:
                messages.error(
                    request, "That code is not valid. Check your authenticator app and try again."
                )
            else:
                profile.totp_enabled = True
                profile.totp_last_step = step
                profile.save(update_fields=["totp_enabled", "totp_last_step", "updated_at"])
                security_logger.info("mfa_enabled user_id=%s", request.user.pk)
                messages.success(request, "Multi-factor authentication is now on.")
        elif action == "disable" and profile.totp_enabled:
            step = totp.verify_code(
                profile.totp_secret, request.POST.get("code"), profile.totp_last_step
            )
            if not request.user.check_password(request.POST.get("password", "")) or step is None:
                messages.error(request, "Incorrect password or code.")
            else:
                profile.totp_enabled = False
                profile.totp_secret = ""
                profile.totp_last_step = 0
                profile.save(
                    update_fields=["totp_enabled", "totp_secret", "totp_last_step", "updated_at"]
                )
                security_logger.info("mfa_disabled user_id=%s", request.user.pk)
                messages.success(request, "Multi-factor authentication is now off.")
        return redirect("gateway:mfa")

    if not profile.totp_enabled and not profile.totp_secret:
        profile.totp_secret = totp.generate_secret()
        profile.save(update_fields=["totp_secret", "updated_at"])

    context = {"mfa_enabled": profile.totp_enabled}
    if not profile.totp_enabled:
        context["secret"] = " ".join(
            profile.totp_secret[i : i + 4] for i in range(0, len(profile.totp_secret), 4)
        )
        context["otpauth_uri"] = totp.provisioning_uri(profile.totp_secret, request.user.email)
    return render(request, "gateway/mfa.html", context)


def blocked(request):
    return render(request, "gateway/blocked.html", status=403)
