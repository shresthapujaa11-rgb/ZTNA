"""Device trust: remember which browsers a user has verified.

A random token is stored in an HttpOnly cookie; only its SHA-256 hash is kept in the
database, so a leaked database can't be used to impersonate a device.
"""

import hashlib
import secrets

from django.conf import settings
from django.utils import timezone

from .models import TrustedDevice

COOKIE_MAX_AGE = 90 * 24 * 60 * 60


def _cookie_name(user):
    # Per-user name so two people sharing a browser don't overwrite each other's token.
    return f"device_id_{user.pk}"


def _hash(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def has_devices(user):
    return TrustedDevice.objects.filter(user=user).exists()


def is_known_device(request, user):
    token = request.COOKIES.get(_cookie_name(user))
    if not token:
        return False
    updated = TrustedDevice.objects.filter(user=user, token_hash=_hash(token)).update(
        last_seen_at=timezone.now()
    )
    return bool(updated)


def register_device(request, response, user):
    """Trust the current browser for `user` and set its cookie on `response`."""
    token = secrets.token_urlsafe(32)
    TrustedDevice.objects.create(
        user=user,
        token_hash=_hash(token),
        user_agent=request.META.get("HTTP_USER_AGENT", "")[:255],
        first_ip=request.META.get("REMOTE_ADDR") or None,
    )
    response.set_cookie(
        _cookie_name(user),
        token,
        max_age=COOKIE_MAX_AGE,
        httponly=True,
        samesite="Lax",
        secure=not settings.DEBUG,
    )


def ensure_device(request, response, user):
    """Trust this browser if it isn't already trusted."""
    if not is_known_device(request, user):
        register_device(request, response, user)


def enroll_first_device(request, response, user):
    """Trust-on-first-use: a user's very first login device is trusted automatically.

    Any later unrecognised device must pass step-up before it is trusted.
    """
    if not has_devices(user):
        register_device(request, response, user)
