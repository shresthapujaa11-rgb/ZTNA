"""Session bookkeeping shared by the login flow and the gateway views."""

from datetime import timedelta

from django.utils import timezone

MFA_PENDING_MINUTES = 5


def mark_verified(request):
    """Record that the user has just proven who they are (login or step-up)."""
    request.session["stepup_verified_at"] = timezone.now().isoformat()


def start_mfa_challenge(request, user):
    """Park a password-verified login until the authenticator code is entered."""
    request.session["mfa_pending"] = {"user_id": user.pk, "at": timezone.now().isoformat()}


def pending_mfa_user_id(request):
    pending = request.session.get("mfa_pending")
    if not pending:
        return None
    try:
        started = timezone.datetime.fromisoformat(pending["at"])
    except (KeyError, ValueError):
        return None
    if timezone.now() - started > timedelta(minutes=MFA_PENDING_MINUTES):
        request.session.pop("mfa_pending", None)
        return None
    return pending.get("user_id")


def clear_mfa_challenge(request):
    request.session.pop("mfa_pending", None)
