from django.urls import path

from . import views

app_name = "gateway"

urlpatterns = [
    path("stepup/", views.stepup, name="stepup"),
    path("blocked/", views.blocked, name="blocked"),
    path("mfa/", views.mfa_setup, name="mfa"),
    path("mfa/login/", views.mfa_login, name="mfa-login"),
]
