from django.contrib import admin

from .models import AccessDecisionLog, AccessPolicy, TrustedDevice, TrustedNetwork, UserAccessProfile


@admin.register(TrustedNetwork)
class TrustedNetworkAdmin(admin.ModelAdmin):
    list_display = ("name", "cidr", "is_active", "created_at")
    list_filter = ("is_active",)
    search_fields = ("name", "cidr")


@admin.register(AccessPolicy)
class AccessPolicyAdmin(admin.ModelAdmin):
    list_display = (
        "is_enabled",
        "business_hours_start",
        "business_hours_end",
        "stepup_risk_threshold",
        "block_risk_threshold",
    )

    def has_add_permission(self, request):
        return not AccessPolicy.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(UserAccessProfile)
class UserAccessProfileAdmin(admin.ModelAdmin):
    list_display = (
        "user",
        "last_ip",
        "last_network_trusted",
        "last_ip_seen_at",
        "failed_stepup_count",
        "totp_enabled",
    )
    search_fields = ("user__email", "user__full_name", "last_ip")
    # The TOTP secret is never shown, even read-only.
    exclude = ("totp_secret",)
    readonly_fields = [
        f.name for f in UserAccessProfile._meta.fields if f.name != "totp_secret"
    ]

    def has_add_permission(self, request):
        return False


@admin.register(AccessDecisionLog)
class AccessDecisionLogAdmin(admin.ModelAdmin):
    list_display = (
        "created_at",
        "user",
        "path",
        "method",
        "risk_level",
        "risk_score",
        "decision",
        "ip_address",
    )
    list_filter = ("risk_level", "decision", "method")
    search_fields = ("user__email", "path", "ip_address", "reasons")
    readonly_fields = [f.name for f in AccessDecisionLog._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(TrustedDevice)
class TrustedDeviceAdmin(admin.ModelAdmin):
    """Deleting a device revokes it: that browser must pass step-up again."""

    list_display = ("user", "user_agent", "first_ip", "created_at", "last_seen_at")
    search_fields = ("user__email", "user_agent", "first_ip")
    readonly_fields = [f.name for f in TrustedDevice._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
