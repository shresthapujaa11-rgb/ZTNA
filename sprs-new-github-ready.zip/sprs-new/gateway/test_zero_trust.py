from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import Client, RequestFactory, SimpleTestCase, TestCase
from django.utils import timezone

from . import loginguard, totp
from .models import AccessPolicy, TrustedDevice, UserAccessProfile

MyUser = get_user_model()
PASSWORD = "Str0ngPassw0rd!"


class TotpTests(SimpleTestCase):
    # RFC 6238 test secret ("12345678901234567890") and its published codes.
    SECRET = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"

    def test_matches_rfc_6238_vectors(self):
        self.assertEqual(totp._code_for_counter(self.SECRET, 59 // 30), "287082")
        self.assertEqual(totp._code_for_counter(self.SECRET, 1111111109 // 30), "081804")

    def test_verify_accepts_current_code_and_rejects_replay_and_garbage(self):
        step = totp.verify_code(self.SECRET, "287082", now=59)
        self.assertEqual(step, 1)
        self.assertIsNone(totp.verify_code(self.SECRET, "287082", last_used_step=step, now=59))
        self.assertIsNone(totp.verify_code(self.SECRET, "000000", now=59))
        self.assertIsNone(totp.verify_code(self.SECRET, "abc", now=59))
        self.assertIsNone(totp.verify_code("", "287082", now=59))


class DeviceTrustTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = MyUser.objects.create_user(
            email="teacher@example.com", password=PASSWORD, role="teacher", is_verified=True
        )
        AccessPolicy.get_solo()

    def login(self, client):
        return client.post("/login/", {"email": "teacher@example.com", "password": PASSWORD})

    def test_first_login_device_is_trusted_automatically(self):
        self.login(self.client)
        self.assertEqual(TrustedDevice.objects.filter(user=self.user).count(), 1)
        self.assertEqual(self.client.get("/home/").status_code, 200)

    def test_unrecognised_device_needs_stepup_and_is_then_trusted(self):
        self.login(self.client)  # first device
        other = Client()
        self.login(other)  # second browser, without the trusted-device cookie
        # Login counts as a fresh verification; drop it so the device check is what fires.
        session = other.session
        session.pop("stepup_verified_at", None)
        session.save()

        response = other.get("/home/")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/gateway/stepup/", response.url)

        done = other.post(response.url, {"password": PASSWORD, "next": "/home/"})
        self.assertRedirects(done, "/home/")
        self.assertEqual(TrustedDevice.objects.filter(user=self.user).count(), 2)
        self.assertEqual(other.get("/home/").status_code, 200)

    def test_only_a_hash_of_the_device_token_is_stored(self):
        response = self.login(self.client)
        token = response.cookies[f"device_id_{self.user.pk}"].value
        stored = TrustedDevice.objects.get(user=self.user).token_hash
        self.assertNotEqual(stored, token)
        self.assertEqual(len(stored), 64)


class AdminStepupGateTests(TestCase):
    def setUp(self):
        cache.clear()
        self.admin = MyUser.objects.create_superuser("root@example.com", PASSWORD)
        AccessPolicy.get_solo()

    def test_admin_area_requires_recent_verification(self):
        self.client.force_login(self.admin)
        response = self.client.get("/admin-portal/")
        self.assertIn("/gateway/stepup/", response.url)

        session = self.client.session
        session["stepup_verified_at"] = timezone.now().isoformat()
        session.save()
        self.assertEqual(self.client.get("/admin-portal/").status_code, 200)

    def test_the_gate_can_be_switched_off(self):
        policy = AccessPolicy.get_solo()
        policy.require_stepup_for_admin = False
        policy.save()
        self.client.force_login(self.admin)
        self.assertEqual(self.client.get("/admin-portal/").status_code, 200)

    def test_admin_login_counts_as_verification(self):
        self.client.post("/login/", {"email": "root@example.com", "password": PASSWORD})
        self.assertEqual(self.client.get("/admin-portal/").status_code, 200)


class MfaFlowTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = MyUser.objects.create_user(
            email="teacher@example.com", password=PASSWORD, role="teacher", is_verified=True
        )
        AccessPolicy.get_solo()
        self.profile = UserAccessProfile.objects.create(
            user=self.user, totp_secret=totp.generate_secret(), totp_enabled=True
        )

    def current_code(self):
        step = int(timezone.now().timestamp() // 30)
        return totp._code_for_counter(self.profile.totp_secret, step)

    def password_step(self):
        return self.client.post(
            "/login/", {"email": "teacher@example.com", "password": PASSWORD}
        )

    def test_password_alone_does_not_log_in_when_mfa_is_on(self):
        response = self.password_step()
        self.assertRedirects(response, "/gateway/mfa/login/", fetch_redirect_response=False)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_correct_code_completes_login(self):
        self.password_step()
        response = self.client.post("/gateway/mfa/login/", {"code": self.current_code()})
        self.assertEqual(response.status_code, 302)
        self.assertIn("_auth_user_id", self.client.session)

    def test_wrong_code_is_rejected(self):
        self.password_step()
        self.client.post("/gateway/mfa/login/", {"code": "000000"})
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_mfa_page_is_not_reachable_without_a_password_step(self):
        response = self.client.get("/gateway/mfa/login/")
        self.assertRedirects(response, "/login/", fetch_redirect_response=False)

    def test_stepup_also_needs_the_code(self):
        self.client.force_login(self.user)
        wrong = self.client.post(
            "/gateway/stepup/", {"password": PASSWORD, "code": "000000", "next": "/home/"}
        )
        self.assertEqual(wrong.status_code, 200)
        right = self.client.post(
            "/gateway/stepup/",
            {"password": PASSWORD, "code": self.current_code(), "next": "/home/"},
        )
        self.assertRedirects(right, "/home/", fetch_redirect_response=False)

    def test_user_can_enable_mfa_from_the_setup_page(self):
        self.profile.totp_enabled = False
        self.profile.save()
        self.client.force_login(self.user)
        self.client.get("/gateway/mfa/")
        self.profile.refresh_from_db()
        self.client.post("/gateway/mfa/", {"action": "enable", "code": self.current_code()})
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.totp_enabled)

    def test_the_totp_secret_is_not_shown_once_mfa_is_enabled(self):
        self.client.force_login(self.user)
        response = self.client.get("/gateway/mfa/")
        self.assertNotContains(response, self.profile.totp_secret)


class LoginGuardTests(TestCase):
    def test_email_case_and_spacing_do_not_bypass_the_lockout(self):
        cache.clear()
        policy = AccessPolicy.get_solo()
        request = RequestFactory().post("/login/")
        for email in ("A@x.com", "a@X.com", " a@x.com ", "A@X.COM", "a@x.com"):
            loginguard.record_failure(request, email, policy)
        self.assertTrue(loginguard.is_locked(request, "a@x.com", policy))
