"""Time-based one-time passwords (RFC 6238), implemented with the standard library."""

import base64
import hashlib
import hmac
import os
import struct
import time
from urllib.parse import quote

STEP_SECONDS = 30
DIGITS = 6


def generate_secret():
    """Return a random base32 secret (160 bits) for an authenticator app."""
    return base64.b32encode(os.urandom(20)).decode("ascii")


def _code_for_counter(secret, counter):
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    value = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF
    return str(value % 10**DIGITS).zfill(DIGITS)


def verify_code(secret, code, last_used_step=0, now=None, window=1):
    """Return the matched time step if `code` is valid, else None.

    Steps at or before `last_used_step` are rejected so a captured code can't be replayed.
    `window` allows for small clock drift between the server and the phone.
    """
    code = (code or "").replace(" ", "").strip()
    if not secret or len(code) != DIGITS or not code.isdigit():
        return None
    current = int((time.time() if now is None else now) // STEP_SECONDS)
    for step in range(current - window, current + window + 1):
        if step <= last_used_step:
            continue
        if hmac.compare_digest(_code_for_counter(secret, step), code):
            return step
    return None


def provisioning_uri(secret, account, issuer="Classroom Access Gateway"):
    label = quote(f"{issuer}:{account}")
    return f"otpauth://totp/{label}?secret={secret}&issuer={quote(issuer)}&digits={DIGITS}&period={STEP_SECONDS}"
