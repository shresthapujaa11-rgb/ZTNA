# Classroom Project Documentation

A simple guide to running the project and understanding how it is built.

---

## 1. What is this project?

A website for a college or school where:

- **Students** register, see their tasks, and upload their work.
- **Teachers** take attendance, give tasks, check submissions, record exam marks, and see a predicted final score for each student.
- **Admins** approve new accounts, create semesters and subjects, and decide which teacher teaches which subject.

On top of this, the project has an extra **security layer** (called the *gateway*) that watches every request and can ask for your password again, or block the request, when something looks suspicious.

---

## 2. Running the project

### What you need

- Python 3.10 or newer (the project has been run on 3.14)
- Nothing else for a basic run. The project uses a local **SQLite** file (`db.sqlite3`) by default. MySQL is optional.

### Step by step (Windows, PowerShell)

```powershell
# 1. Go to the project folder
cd C:\project\sprs-new

# 2. Create and activate a virtual environment (first time only)
python -m venv .venv
.venv\Scripts\Activate.ps1

# 3. Install the libraries
pip install -r requirements.txt

# 4. Create your settings file (first time only)
copy .env.example .env

# 5. Create/update the database tables
python manage.py migrate

# 6. Create an admin account (first time only)
python manage.py createsuperuser

# 7. Start the website
python manage.py runserver
```

Then open **http://127.0.0.1:8000/** in your browser.

> This repo also contains a ready-made environment in `.venv-win`. On this machine you can run
> `.venv-win\Scripts\python.exe manage.py runserver` instead of steps 2 and 3.

### Useful commands

| Command | What it does |
| --- | --- |
| `python manage.py runserver` | Starts the website |
| `python manage.py migrate` | Creates or updates the database tables |
| `python manage.py createsuperuser` | Creates an admin account |
| `python manage.py test` | Runs all automatic tests |
| `python manage.py check` | Checks the project for configuration problems |

### Settings (the `.env` file)

`core/settings.py` reads a file called `.env` in the project root. It is not uploaded to Git.

| Setting | Meaning |
| --- | --- |
| `DJANGO_SECRET_KEY` | Secret value Django uses for sessions and security. Use a long random value. |
| `DJANGO_DEBUG` | `True` while developing, **`False` when the site is live**. |
| `DJANGO_ALLOWED_HOSTS` | Website addresses allowed to reach the app, e.g. `127.0.0.1,localhost`. |
| `DB_ENGINE` | Leave it out to use SQLite. Set to `mysql` to use MySQL. |
| `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT` | MySQL connection details (only used when `DB_ENGINE=mysql`). |

### Important pages

| Address | Who uses it |
| --- | --- |
| `/login/` | Everyone |
| `/student-register/`, `/teacher-register/` | New students and teachers |
| `/home/` | Logged-in students and teachers |
| `/admin-portal/` | Admins (the project's own admin area) |
| `/admin/` | Django's built-in admin, also used to configure the gateway |

---

## 3. First-time walkthrough

1. Create an admin with `createsuperuser`, then log in at `/login/`. You land on the **Admin Portal**.
2. **Semesters**: add a semester (for example "First"), then open it and add its subjects.
3. A student or teacher registers on the register pages. Their account is **locked until an admin approves it**: logging in says *"Your account is awaiting administrator approval."*
4. In the Admin Portal open **Approvals** (or Students / Teachers) and click **Approve / Verify**.
5. **Assign Teachers**: connect each teacher to a subject.
6. Now the teacher can create tasks, take attendance and record marks. Students in that semester can see the tasks and submit work.

---

## 4. Project structure

```text
sprs-new/
├── manage.py            Command-line entry point
├── requirements.txt     Python libraries the project needs
├── .env / .env.example  Settings (secrets stay out of Git)
├── db.sqlite3           The database file (SQLite)
├── core/                Project settings and the top-level URL list
├── classroom/           The main app: users, tasks, attendance, marks, admin portal
│   ├── models.py        Database tables
│   ├── views.py         The logic behind every page
│   ├── urls.py          Which web address goes to which view
│   ├── security.py      Permission check and file-upload checks
│   ├── validation.py    Small input checks (empty, name format, ...)
│   ├── signals.py       Automatic roll-number numbering
│   ├── context.py       Puts the user's subject list into every page
│   ├── middleware.py    Writes a security log line for every form submission
│   ├── templates/       HTML pages
│   ├── static/          CSS and JavaScript
│   └── tests.py         Automatic tests
├── gateway/             The security layer (risk scoring, step-up, blocking)
├── templates/           Shared page parts (layout, navbar, sidebar, messages)
├── utils/               The score-prediction code and its training data
└── media/               Uploaded files (profile photos, task files, submissions)
```

---

## 5. System architecture

### 5.1 The big picture

```text
   Browser (student / teacher / admin)
                 │
                 ▼
┌────────────────────────────────────────────┐
│ Django middleware (runs on every request)  │
│  • sessions, CSRF protection               │
│  • login lookup (who is this user?)        │
│  • security-event logger  (classroom)      │
│  • Access gateway         (gateway)        │
└────────────────────────────────────────────┘
                 │
                 ▼
        urls.py  →  view (views.py)
                 │        │
                 │        ├── permission checks (role + subject access)
                 │        ├── input and file validation
                 │        └── reads/writes the database
                 ▼
        Template (HTML)  →  page sent back to the browser
                 
   Database (SQLite or MySQL)      Files on disk (media/)
```

In words: a request arrives, passes through the middleware, is matched to a view by its address, the view checks that the user is allowed to do it, works with the database and uploaded files, and returns an HTML page.

### 5.2 Technology used

| Part | Technology |
| --- | --- |
| Web framework | Django (`requirements.txt` pins 4.2; the local environment currently runs 5.2 and passes all tests) |
| Database | SQLite by default, MySQL optional (through PyMySQL) |
| Pages | Django templates with Bootstrap 5 |
| Admin styling | Django Jazzmin |
| Score prediction | NumPy and pandas |
| Image uploads | Pillow |

### 5.3 The two apps

- **`classroom`** is the school itself: users, subjects, tasks, attendance, marks, predictions and the admin portal.
- **`gateway`** is the security guard. It doesn't care about school content. It only looks at *who* is making a request and *from where*, and decides whether to let it through.

---

## 6. Users and roles

There is one user table for everyone (`MyUser`). The `role` column decides what they can do. Users log in with their **email**.

| Role | How they get it | Where they go after login |
| --- | --- | --- |
| **Student** | Registers at `/student-register/` and picks a semester | `/home/` |
| **Teacher** | Registers at `/teacher-register/` (phone number required) | `/home/` |
| **Admin** | Created with `createsuperuser` | `/admin-portal/` |

Every student and teacher account starts **unverified** and cannot log in until an admin approves it. Admins created with `createsuperuser` are verified automatically.

### What each role can do

| Feature | Student | Teacher | Admin |
| --- | :---: | :---: | :---: |
| Register / log in | ✔ | ✔ | ✔ |
| See tasks of own subjects | ✔ | ✔ | |
| Submit an assignment (PDF) | ✔ | | |.venv-win\Scripts\python.exe manage.py runserver

| See own remarks and score | ✔ | | |
| Create, edit, delete tasks | | ✔ | |
| Take attendance | | ✔ | |
| Review submissions, give score and feedback | | ✔ | |
| Record mid-term / pre-board marks | | ✔ | |
| See predicted final score | | ✔ | |
| Approve or reject accounts | | | ✔ |
| Manage semesters and subjects | | | ✔ |
| Assign teachers to subjects | | | ✔ |
| Edit or delete students and teachers | | | ✔ |

A teacher only sees subjects assigned to them. A student only sees subjects of their own semester. This rule lives in `can_access_subject()` in `classroom/security.py` and is checked in every subject page.

---

## 7. The database (what is stored)

```text
Semester ──< Subject ──< Task ──< Submission ──< Remark
   │            │                      │
   │            ├──< Attendance >──────┤
   │            ├──< ExamResults >─────┤
   │            └──< TeacherTeaches >──┼── teacher (MyUser)
   └──< MyUser (students)  ───────────┘
```

(`A ──< B` means "one A has many B".)

| Table (model) | What it holds |
| --- | --- |
| **MyUser** | Everyone: name, email, password (stored hashed), phone, role, roll number, profile photo, semester, `is_verified` |
| **Semester** | A term, e.g. "First" |
| **Section** | An optional group inside a semester |
| **Subject** | A subject inside a semester. The URL name (`slug`) is made from the subject name |
| **TeacherTeaches** | Which teacher teaches which subject. A subject can have only one teacher, and a teacher can teach only one subject per semester |
| **Task** | An assignment, lab report, presentation or case study, with a PDF file, due date, and "submit online or on paper" |
| **Submission** | A student's uploaded answer. One per student per task. Status: unchecked, checked, rejected |
| **Remark** | The teacher's score (0 to 10) and feedback for a submission |
| **Attendance** | One row per student, subject and date: present or absent |
| **ExamResults** | Marks for the mid-term or pre-board exam, with full marks and percentage |

Gateway tables (in the `gateway` app) are described in section 9.

**Roll numbers** are assigned automatically. Whenever a student is added, moved to another semester, or deleted, the students of that semester are renumbered 1, 2, 3... in alphabetical order (`classroom/signals.py`).

---

## 8. How the main features work

### 8.1 Sign up and approval

1. A user fills in the register form. The server checks that all fields are filled, the email is valid, the passwords match, the password is strong enough, and the profile image is a real image.
2. The account is saved with `is_verified = False`.
3. At login, if the account is not verified the user sees "awaiting administrator approval".
4. An admin clicks **Approve** on the Approvals page. **Reject** deletes the account.

### 8.2 Tasks and submissions

1. The teacher creates a task: type, description (at least 10 characters), due date (today or later), and a **PDF**.
2. Students of that semester see it. If the task allows online submission and the due date has not passed, they upload a PDF.
3. The teacher opens the submission, gives a score from 0 to 10, a status and feedback.
4. The student sees the remark. A student can delete a submission only if it was **rejected**, so they can send it again.

### 8.3 Attendance

The teacher opens the subject's attendance page, ticks the students who are present, and saves. Saving again on the same day updates the same records. Past dates are listed and can be opened and corrected.

### 8.4 Marks

The teacher picks **Mid Term** or **Pre Board**, enters the full marks and each student's marks. The server checks every value is a whole number from 0 to full marks. Either all marks are saved or none are. Saved marks can be viewed and edited later.

### 8.5 Score prediction

Found in `utils/regression.py`.

- The model is a **linear regression** trained once from `utils/csv_dataset.csv` (about 99 example students).
- It learns how these four numbers relate to the final board score: **attendance %**, **average task score %**, **mid-term %**, **pre-board %**.
- For each student the teacher sees these four values and the predicted final score, limited to the range 0 to 99.
- Missing values (for example no mid-term yet) count as 0.

### 8.6 Admin portal

Dashboard, Students, Teachers, Approvals, Semesters (with each semester's subjects) and Assign Teachers. All admin actions that change data (verify, reject, delete) only work as form submissions (POST) from a logged-in admin.

---

## 9. The security layer

### 9.1 Basic protections

| Protection | Where |
| --- | --- |
| Passwords stored hashed; strength rules on sign-up | Django + `AUTH_PASSWORD_VALIDATORS` |
| Login required for all inner pages | `@login_required` in `views.py` |
| Role and subject checks on the server | `views.py`, `security.py` |
| CSRF tokens on every form | Django middleware |
| File uploads checked by extension, size and real file signature | `security.py` |
| SHA-256 fingerprint saved for each task file and submission | `attachment_sha256` fields |
| Security log line for every form submission (no form contents) | `classroom/middleware.py` |
| Login success/failure and permission-denied events are logged | `views.py` |
| Uploaded files served only to permitted users | `protected_media` in `views.py`, `can_access_media` in `security.py` |
| Login lockout after repeated failures | `gateway/loginguard.py` |
| Optional authenticator-app MFA | `gateway/totp.py`, `gateway/views.py` |
| Trusted-device recognition | `gateway/devices.py` |

Upload limits: task files and submissions must be **PDF**, up to **10 MB**. Profile pictures must be **jpg, jpeg, png or webp**, up to **5 MB**.

### 9.2 The access gateway (zero trust)

Idea: *never trust, always verify.* Being logged in is not enough. On every request, the gateway asks "does this still look like the real user?"

```text
Logged-in request
      │
      ▼
Gateway adds up a risk score
      │
      ├─ score below 30   → allowed
      ├─ score 30 to 69   → user must re-enter their password (step-up)
      └─ score 70 or more → blocked (403 page)
```

Points added to the score (`gateway/risk.py`):

| Signal | Points |
| --- | --- |
| Request comes from an IP outside the trusted networks (only if trusted networks are configured) | 25 |
| Network changed too quickly since the last request ("impossible travel") | 40 |
| A change (POST, PUT, PATCH, DELETE) made outside business hours (6:00–22:00 by default) | 20 |
| Too many changes in a short time (20 in 60 seconds by default) | 25 |
| Earlier failed step-up attempts (10 each, at most 30) | up to 30 |
| A browser this user has not verified before (only once the user already has a trusted device) | 30 |

Not checked by the gateway: `/static/`, the gateway's own pages, and `/logout/`. Uploaded files under `/media/` **are** checked (see 9.3).

After a correct password (and authenticator code, if MFA is on) at the step-up page, the user is trusted for **15 minutes** (default). Every decision is stored in `AccessDecisionLog` for review.

**Administrator areas** (`/admin-portal/`, `/admin/`, and the verify, reject and delete actions) have an extra rule: an admin must have verified within the last 15 minutes, whatever the risk score. Signing in counts as a verification, so this only asks again after a pause.

The gateway is configured in **Django admin** (`/admin/`):

| Table | Purpose |
| --- | --- |
| **AccessPolicy** | One row with the business hours, thresholds, limits, login lockout settings, the admin-area rule, the device-trust switch, and an on/off switch |
| **TrustedNetwork** | Trusted IP ranges, e.g. `192.168.1.0/24` |
| **UserAccessProfile** | Remembers each user's last IP, failed step-ups and whether MFA is on (filled automatically; the MFA secret is never shown) |
| **TrustedDevice** | Browsers a user has verified. Delete a row to revoke that browser |
| **AccessDecisionLog** | History of allow, step-up and block decisions |

### 9.3 Zero trust extras

**Protected uploads.** Files are no longer public static files. `/media/...` goes through a view that checks who is asking: a task file is available to that subject's teacher and the students of its semester; a submission only to the student who made it and the subject's teacher; a profile picture only to its owner. Admins can open everything. Anything not matching a database record is refused, and `..` path tricks return 404.

**Login lockout.** After 5 failed logins for one email within 15 minutes (or 20 from one IP address), logins are refused until the window ends, even with the right password. Each refused attempt is written to `AccessDecisionLog`. Both numbers are set in `AccessPolicy`.

**Device trust.** The first browser a user logs in from is trusted automatically. The browser gets a random token in an HttpOnly cookie, and only a hash of it is stored. If the same account later appears from a browser without that token, the request scores 30 and triggers step-up. After a successful step-up that browser is trusted too.

**Multi-factor authentication (MFA).** Any user can turn on an authenticator app (Google Authenticator, Microsoft Authenticator, Authy) from the menu: *Security (MFA)*. Add the setup key to the app, type the current 6-digit code and press *Turn on*. From then on:

- login needs the password **and** the code;
- step-up needs the password **and** a code;
- each code works only once.

This is the standard TOTP method (RFC 6238), written with Python's standard library, so no extra package is needed.

**Shorter sessions.** A login lasts 8 hours by default (`SESSION_AGE_SECONDS` in `.env`).

Known limits: a form submission that triggers step-up must be sent again afterwards; request counting is per-process and resets on restart; the "impossible travel" check is a simple IP-change rule, not real location lookup; the gateway trusts only the direct connection IP, not `X-Forwarded-For`; the MFA secret is stored as plain text in the database (fine for a lab, but a production system should encrypt it); there are no backup codes, so an admin has to switch MFA off for a user who loses their phone.

---

## 10. How one request flows (example)

*A teacher saves attendance:*

1. Browser sends `POST /attendance/maths/`.
2. Middleware: session loaded, CSRF token checked, user identified.
3. Gateway: scores the request; low risk, so it continues.
4. URL list sends it to `views.attendance`.
5. The view checks: logged in, role is teacher, this teacher teaches Maths.
6. It saves one Attendance row per student, then redirects back with a "saved" message.
7. The security middleware writes a log line: method, path, status, user id.

---

## 11. Testing

Run all tests:

```powershell
python manage.py test
```

The tests cover file validation, admin routes, superuser creation, roll numbering, marks and task validation, the gateway risk rules, protected uploads, login lockout, device trust, the admin-area rule, and the MFA login and step-up flows.

---

## 12. Troubleshooting

| Problem | Reason and fix |
| --- | --- |
| "Your account is awaiting administrator approval." | The account isn't approved. Log in as admin and approve it in Admin Portal → Approvals. |
| Sent to `/login/?next=...` | You are logged out. Log in first. |
| Blank subject list in the navbar | Teacher has no subject assigned, or the student has no semester. Use Assign Teachers / Edit Student. |
| Asked for your password again | The gateway's step-up (new browser, unusual activity, or an admin area after 15 idle minutes). Enter your password (and code, if MFA is on). |
| "Too many failed login attempts" | The lockout. Wait 15 minutes, or restart the server (the counter is in memory). |
| Lost the phone with the authenticator app | An admin can clear the user's MFA in Django admin: open *User access profiles*, or run `UserAccessProfile.objects.filter(user__email=...).update(totp_enabled=False, totp_secret="")` in `manage.py shell`. |
| An uploaded file gives "Not Found" | You may not be allowed to see it, or the file is missing. Files are only served to permitted users. |
| "Access blocked" page | Risk score too high. Check the log in Django admin; adjust `AccessPolicy` or `TrustedNetwork` if it is a false alarm. |
| Cannot connect to MySQL | You set `DB_ENGINE=mysql`. Remove it to use SQLite, or fix the `DB_*` values. |

---

## 13. Notes for deployment

- Set `DJANGO_DEBUG=False` and a real `DJANGO_SECRET_KEY`. With debug off the site forces HTTPS and secure cookies.
- Set `DJANGO_ALLOWED_HOSTS` to your real domain.
- Static files should be served by a web server. Uploaded files must **keep going through Django** (`/media/`), because that is what checks permissions. If you move them to a web server, use an authenticated internal redirect (for example nginx `X-Accel-Redirect`) rather than a public folder.
- Use a shared cache such as Redis if you run several worker processes, so the gateway's rate counting works.
- Check the timezone: `TIME_ZONE` is `UTC`, so the gateway's business hours are judged in UTC.
- Run `python manage.py check --deploy` and read the warnings.
- To go further towards full ZTNA, put the app behind an identity-aware broker (Cloudflare Access, Tailscale, Pomerium or WireGuard) so it is never directly reachable, and update `gateway/risk.py::get_client_ip` to read that broker's trusted header.
