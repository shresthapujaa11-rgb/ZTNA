import numpy as np
import pandas as pd
import os

class MyLinearRegression:
    def __init__(self):
        self.coef_ = None
        self.intercept_ = None

    def fit(self, X_data, y_data):
        X_data = np.insert(X_data, 0, 1, axis=1)
        # β =  (X^T.X)^(-1).X^T.Y
        betas = np.linalg.inv(np.dot(X_data.T, X_data)).dot(X_data.T).dot(y_data) 
        self.intercept_ = betas[0]
        self.coef_ = betas[1:]

    def predict(self, X_test):
        X_test_with_intercept = np.insert(X_test, 0, 1, axis=1)
        # Y ̂_Ram = β0 + β1 X1 + β2 X2 + β3 X3 + β4 X4
        y_pred = np.dot(X_test_with_intercept, np.concatenate(([self.intercept_], self.coef_)))
        return y_pred

base_dir = os.path.dirname(os.path.abspath(__file__))
csv_path = os.path.join(base_dir, "csv_dataset.csv")

_model = None


def _get_model():
    """Fit the regression model once and reuse it for every prediction call."""
    global _model
    if _model is None:
        df = pd.read_csv(csv_path)
        X_data = df[["attendance", "task", "mid_term", "pre_board"]].values
        y_data = df["board"].values
        _model = MyLinearRegression()
        _model.fit(X_data, y_data)
    return _model


def predict_final_exam_score(attendance, task, mid_term, pre_board):
    lr = _get_model()
    new_student_scores = np.array([attendance, task, mid_term, pre_board]).reshape(1, -1)
    predicted_final_exam_score = lr.predict(new_student_scores)

    # Ensure the predicted score is within the range [0, 99]
    predicted_final_exam_score = max(0, predicted_final_exam_score[0])
    predicted_final_exam_score = min(99, predicted_final_exam_score)

    return predicted_final_exam_score

